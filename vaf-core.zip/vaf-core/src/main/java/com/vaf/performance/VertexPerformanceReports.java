package com.vaf.performance;

import com.vaf.steps.GatlingSteps;
import com.vaf.utils.ConfigUtil;
import com.vaf.utils.ExcelUtil;
import io.gatling.javaapi.core.ChainBuilder;
import io.gatling.javaapi.core.ScenarioBuilder;
import io.gatling.javaapi.core.Simulation;
import io.gatling.javaapi.http.HttpProtocolBuilder;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static com.vaf.api.APIManager.jsonToMap;
import static com.vaf.api.APIManager.jsonToMaps;
import static io.gatling.javaapi.core.CoreDsl.*;
import static io.gatling.javaapi.http.HttpDsl.http;
import static io.gatling.javaapi.http.HttpDsl.status;

/**
 * The class for defining Gatling performance reports.
 */
public class VertexPerformanceReports extends Simulation {
    ExcelUtil excelUtil = new ExcelUtil();        // Create Object of ExcelUtil Class
    public static String sessionResponse = "{}";  // Stores the JSON response
    public static Integer maxResponseTime = 1200;  // Max response time threshold
    String excelKey = GatlingSteps.keyOfExcel;     // Excel key for data retrieval
    String userType = GatlingSteps.typeOfUsers;    // Type of users (rampUsers, constant user per second, etc.)
    String requestName = GatlingSteps.nameOfRequest; // Request name
    String jsonRequestBody = GatlingSteps.excelBody; // JSON request body
    String urlEncodedBody = ""; // URL-encoded request body
    String username = ""; // Username for basic authentication
    String password = ""; // Password for basic authentication
    String jsonUrlBody = GatlingSteps.typeOfBody; // JSON or URL-encoded body type
    ArrayList<String> dataOfRequest = (ArrayList<String>) excelUtil.getPerformanceData(excelKey); // Fetch request data from Excel

    /**
     * Converts the JSON request body to URL-encoded format.
     */
    public void convertJsonToUrlEncodedBody() {

        // Convert the JSON request body to a map
        Map<String, String> bodyMap = jsonToMap(jsonRequestBody);

        // Create a StringBuilder to build the URL-encoded body
        StringBuilder urlEncodeBuilder = new StringBuilder();

        // Loop through the entries in the body map
        for (Map.Entry<String, String> entry : bodyMap.entrySet()) {

            // Append '&' if there are previous entries in the URL-encoded body
            if (urlEncodeBuilder.length() != 0) {
                urlEncodeBuilder.append('&');
            }
            // URL-encode the entry's key and value, and append to the URL-encoded body
            urlEncodeBuilder.append(URLEncoder.encode(entry.getKey(), StandardCharsets.UTF_8));
            urlEncodeBuilder.append('=');
            urlEncodeBuilder.append(URLEncoder.encode(entry.getValue(), StandardCharsets.UTF_8));
        }
        // Convert the StringBuilder to a string and store it as the URL-encoded body
        urlEncodedBody = urlEncodeBuilder.toString();
    }
    /**
     * Retrieves authentication data from Excel.
     */
    public void getAuthenticationData() {

        // Get the authentication data from the request data list (index 4)
        String basicAuthData = dataOfRequest.get(4);

        // Check if authentication data is not null and not empty
        if (dataOfRequest.get(4) != null && !dataOfRequest.get(4).isEmpty()) {

            // Convert the authentication data JSON string to a map
            HashMap<String, String> basicAuthMap = jsonToMap(basicAuthData);

            // Retrieve the username and password from the basicAuthMap
            username = basicAuthMap.get("Username");
            password = basicAuthMap.get("Password");
        }
    }

    /**
     * Performs various setup steps for performance reporting.
     */
    public void startPerformanceReporting(){

        //Call convertJsonToUrlEncodedBody() method to convert json body to URLEncoded body
        convertJsonToUrlEncodedBody();

        //Call getAuthenticationData() method to get username and password from EXcel
        getAuthenticationData();

        // Retrieve necessary configuration values
        String requestType = GatlingSteps.typeOfRequest;
        int totalUsers = GatlingSteps.totalNoOfUsers;
        int durations = GatlingSteps.timeDuration;
        String apiEndpoints = GatlingSteps.apiEndpoint;
        int numericValues=GatlingSteps.numericValue;
        int loop = GatlingSteps.loops;

        // Construct the API endpoint and base URI
        String ep = ConfigUtil.GET_ENDPOINT(apiEndpoints);
        String baseUri = ConfigUtil.BASEURI("auth");

        // Retrieve request header and query parameters
        String requestHeader = GatlingSteps.excelHeader;
        String requestQueryParameter = GatlingSteps.excelQueryParameters;
        HashMap<String, Object> mapQueryParameters = jsonToMaps(requestQueryParameter);
        Map<String, String> mapHeaders = jsonToMap(requestHeader);
        String requestMethod = requestType.toLowerCase();

        // Prepare the HTTP protocol configuration
        HttpProtocolBuilder httpProtocol =
                http.baseUrl(baseUri)
                        .acceptHeader("text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                        .acceptLanguageHeader("en-US,en;q=0.5")
                        .acceptEncodingHeader("gzip, deflate")
                        .userAgentHeader("Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8; rv:16.0) Gecko/20100101 Firefox/16.0");

        // Define chain builders for different HTTP request types and scenarios

        //Define chain builder for PUT request without authentication
        ChainBuilder putWithOutAuth =
                repeat(loop).on(                               //Apply loop to repeat the step multiple times
                        exec(http(requestName)            //requestName will reflect on gatling reports
                                .put(ep)
                                .queryParamMap(mapQueryParameters)
                                .body(StringBody(jsonUrlBody.equalsIgnoreCase("json") ? jsonRequestBody : urlEncodedBody))
                                .headers(mapHeaders)
                                .check(status().is(200)) // Check the HTTP status code (modify '200' accordingly)
                                .check(jsonPath("$").saveAs("previousResponse")) // Save the full response body to a session variable
                        )
                );

        //Define chain builder for PUT request with authentication
        ChainBuilder putWithAuth =
                repeat(loop).on(                            //Apply loop to repeat the step multiple times
                        exec(http(requestName)          //requestName will reflect on gatling reports
                                .put(ep)
                                .queryParamMap(mapQueryParameters)
                                .body(StringBody(jsonUrlBody.equalsIgnoreCase("json") ? jsonRequestBody : urlEncodedBody))
                                .headers(mapHeaders).basicAuth(username, password)
                                .check(status().is(200))        // Check the HTTP status code (modify '200' accordingly)
                                .check(jsonPath("$").saveAs("previousResponse"))  // Save the full response body to a session variable
                        )
                );

        //Define chain builder for Post request without authentication
        ChainBuilder postWithOutAuth =
                repeat(loop).on(                                //Apply loop to repeat the step multiple times
                        exec(http(requestName)              //requestName will reflect on gatling reports
                                .post(ep)
                                .queryParamMap(mapQueryParameters)
                                .body(StringBody(jsonUrlBody.equalsIgnoreCase("json") ? jsonRequestBody : urlEncodedBody))
                                .headers(mapHeaders)
                                .check(status().is(200))            // Check the HTTP status code (modify '200' accordingly)
                                .check(jsonPath("$").saveAs("previousResponse"))  // Save the full response body to a session variable
                        )
                );

        //Define chain builder for Post request with authentication
        ChainBuilder postWithAuth =
                repeat(loop).on(                            //Apply loop to repeat the step multiple times
                        exec(http(requestName)          //requestName will reflect on gatling reports
                                .post(ep)
                                .queryParamMap(mapQueryParameters)
                                .body(StringBody(jsonUrlBody.equalsIgnoreCase("json") ? jsonRequestBody : urlEncodedBody))
                                .headers(mapHeaders).basicAuth(username, password)
                                .check(status().is(200))                // Check the HTTP status code (modify '200' accordingly)
                                .check(jsonPath("$").saveAs("previousResponse"))// Save the full response body to a session variable
                        )
                );

        //Define chain builder for Delete request without authentication
        ChainBuilder deleteWithOutAuth =
                repeat(loop).on(                            //Apply loop to repeat the step multiple times
                        exec(http(requestName)          //requestName will reflect on gatling reports
                                .delete(ep)
                                .queryParamMap(mapQueryParameters)
                                .body(StringBody(jsonUrlBody.equalsIgnoreCase("json") ? jsonRequestBody : urlEncodedBody))
                                .headers(mapHeaders)
                                .check(status().is(200))        // Check the HTTP status code (modify '200' accordingly)
                                .check(jsonPath("$").saveAs("previousResponse"))  // Save the full response body to a session variable
                        )
                );

        //Define chain builder for Delete request with authentication
        ChainBuilder deleteWithAuth =
                repeat(loop).on(                            //Apply loop to repeat the step multiple times
                        exec(http(requestName)          //requestName will reflect on gatling reports
                                .delete(ep)
                                .queryParamMap(mapQueryParameters)
                                .body(StringBody(jsonUrlBody.equalsIgnoreCase("json") ? jsonRequestBody : urlEncodedBody))
                                .headers(mapHeaders).basicAuth(username, password)
                                .check(status().is(200))            // Check the HTTP status code (modify '200' accordingly)
                                .check(jsonPath("$").saveAs("previousResponse"))    // Save the full response body to a session variable
                        )
                );

        //Define chain builder for Get request without authentication
        ChainBuilder getWithOutAuth =
                repeat(loop).on(                            //Apply loop to repeat the step multiple times
                        exec(http(requestName)          //requestName will reflect on gatling reports
                                .get(ep)
                                .queryParamMap(mapQueryParameters)
                                .body(StringBody(jsonUrlBody.equalsIgnoreCase("json") ? jsonRequestBody : urlEncodedBody))
                                .headers(mapHeaders)
                                .check(status().is(200))             // Check the HTTP status code (modify '200' accordingly)
                                .check(jsonPath("$").saveAs("previousResponse"))  // Save the full response body to a session variable
                        )
                );

        //Define chain builder for Get request with authentication
        ChainBuilder getWithAuth =
                repeat(loop).on(                //Apply loop to repeat the step multiple times
                        exec(http(requestName)   //requestName will reflect on gatling reports
                                .get(ep)
                                .queryParamMap(mapQueryParameters)
                                .body(StringBody(jsonUrlBody.equalsIgnoreCase("json") ? jsonRequestBody : urlEncodedBody))
                                .headers(mapHeaders).basicAuth(username, password)
                                .check(status().is(200))         // Check the HTTP status code (modify '200' accordingly)
                                .check(jsonPath("$").saveAs("previousResponse"))        // Save the full response body to a session variable
                        )
                );
        // Define scenarios for different request types and authentication settings

        //Define scenario for PUT requests without authentication
        ScenarioBuilder putNonAuth = scenario("putNonAuth").exec(putWithOutAuth).exec(session -> {
            sessionResponse = session.getString("previousResponse").toString();
            System.out.println("Response Data: " + sessionResponse);
            return session;
        });

        //Define scenario for PUT requests with authentication
        ScenarioBuilder putAuth = scenario("putAuth").exec(putWithAuth).exec(session -> {
            sessionResponse = session.getString("previousResponse").toString();
            System.out.println("Response Data: " + sessionResponse);
            return session;
        });

        //Define scenario for Post requests without authentication
        ScenarioBuilder postNonAuth = scenario("postNonAuth").exec(postWithOutAuth).exec(session -> {
            sessionResponse = session.getString("previousResponse").toString();
            System.out.println("Response Data: " + sessionResponse);
            return session;
        });

        //Define scenario for Post requests without authentication
        ScenarioBuilder postAuth = scenario("postAuth").exec(postWithAuth).exec(session -> {
            sessionResponse = session.getString("previousResponse").toString();
            System.out.println("Response Data: " + sessionResponse);
            return session;
        });

        //Define scenario for Delete requests without authentication
        ScenarioBuilder deleteNonAuth = scenario("deleteNonAuth").exec(deleteWithOutAuth).exec(session -> {
            sessionResponse = session.getString("previousResponse").toString();
            System.out.println("Response Data: " + sessionResponse);
            return session;
        });

        //Define scenario for Delete requests with authentication
        ScenarioBuilder deleteAuth = scenario("deleteAuth").exec(deleteWithAuth).exec(session -> {
            sessionResponse = session.getString("previousResponse").toString();
            System.out.println("Response Data: " + sessionResponse);
            return session;
        });

        //Define scenario for Get requests without authentication
        ScenarioBuilder getNonAuth = scenario("getNonAuth").exec(getWithOutAuth).exec(session -> {
            sessionResponse = session.getString("previousResponse").toString();
            System.out.println("Response Data: " + sessionResponse);
            return session;
        });

        //Define scenario for Get requests with authentication
        ScenarioBuilder getAuth = scenario("getAuth").exec(getWithAuth).exec(session -> {
            sessionResponse = session.getString("previousResponse").toString();
            System.out.println("Response Data: " + sessionResponse);
            return session;
        });

        // Perform conditional setup based on user type and request type

        // Set up scenarios and injections for (rampUsers) user type & apply assertion that maximum response time will be less than maxResponseTime(variable)
        if (userType.equals("rampUsers")) {
            if (requestMethod.equalsIgnoreCase("put")) {
                if (dataOfRequest.get(4) != null && !dataOfRequest.get(4).isEmpty()) {
                    setUp(putAuth.injectOpen(rampUsers(totalUsers).during(durations))).protocols(httpProtocol).assertions(global().responseTime().max().lt(maxResponseTime));
                } else {
                    setUp(putNonAuth.injectOpen(rampUsers(totalUsers).during(durations))).protocols(httpProtocol).assertions(global().responseTime().max().lt(maxResponseTime));
                }
            } else if (requestMethod.equalsIgnoreCase("post")) {
                if (dataOfRequest.get(4) != null && !dataOfRequest.get(4).isEmpty()) {
                    setUp(postAuth.injectOpen(rampUsers(totalUsers).during(durations))).protocols(httpProtocol).assertions(global().responseTime().max().lt(maxResponseTime));
                } else {
                    setUp(postNonAuth.injectOpen(rampUsers(totalUsers).during(durations))).protocols(httpProtocol).assertions(global().responseTime().max().lt(maxResponseTime));
                }
            } else if (requestMethod.equalsIgnoreCase("delete")) {
                if (dataOfRequest.get(4) != null && !dataOfRequest.get(4).isEmpty()) {
                    setUp(deleteAuth.injectOpen(rampUsers(totalUsers).during(durations))).protocols(httpProtocol).assertions(global().responseTime().max().lt(maxResponseTime));
                } else {
                    setUp(deleteNonAuth.injectOpen(rampUsers(totalUsers).during(durations))).protocols(httpProtocol).assertions(global().responseTime().max().lt(maxResponseTime));
                }
            } else if (requestMethod.equalsIgnoreCase("get")) {
                if (dataOfRequest.get(4) != null && !dataOfRequest.get(4).isEmpty()) {
                    setUp(getAuth.injectOpen(rampUsers(totalUsers).during(durations))).protocols(httpProtocol).assertions(global().responseTime().max().lt(maxResponseTime));
                } else {
                    setUp(getNonAuth.injectOpen(rampUsers(totalUsers).during(durations))).protocols(httpProtocol).assertions(global().responseTime().max().lt(maxResponseTime));
                }
            }
        }
// Set up scenarios and injections for (constant user per second) user type & apply assertion that maximum response time will be less than maxResponseTime(variable)
        else if(userType.equals("constant user per second")){
            if (requestMethod.equalsIgnoreCase("put")) {
                if (dataOfRequest.get(4) != null && !dataOfRequest.get(4).isEmpty()) {
                    setUp(putAuth.injectOpen(constantUsersPerSec(totalUsers).during(durations))).protocols(httpProtocol).assertions(global().responseTime().max().lt(maxResponseTime));
                } else {
                    setUp(putNonAuth.injectOpen(constantUsersPerSec(totalUsers).during(durations))).protocols(httpProtocol).assertions(global().responseTime().max().lt(maxResponseTime));
                }
            } else if (requestMethod.equalsIgnoreCase("post")) {
                if (dataOfRequest.get(4) != null && !dataOfRequest.get(4).isEmpty()) {
                    setUp(postAuth.injectOpen(constantUsersPerSec(totalUsers).during(durations))).protocols(httpProtocol).assertions(global().responseTime().max().lt(maxResponseTime));
                } else {
                    setUp(postNonAuth.injectOpen(constantUsersPerSec(totalUsers).during(durations))).protocols(httpProtocol).assertions(global().responseTime().max().lt(maxResponseTime));
                }
            } else if (requestMethod.equalsIgnoreCase("delete")) {
                if (dataOfRequest.get(4) != null && !dataOfRequest.get(4).isEmpty()) {
                    setUp(deleteAuth.injectOpen(constantUsersPerSec(totalUsers).during(durations))).protocols(httpProtocol).assertions(global().responseTime().max().lt(maxResponseTime));
                } else {
                    setUp(deleteNonAuth.injectOpen(constantUsersPerSec(totalUsers).during(durations))).protocols(httpProtocol).assertions(global().responseTime().max().lt(maxResponseTime));
                }
            } else if (requestMethod.equalsIgnoreCase("get")) {
                if (dataOfRequest.get(4) != null && !dataOfRequest.get(4).isEmpty()) {
                    setUp(getAuth.injectOpen(constantUsersPerSec(totalUsers).during(durations))).protocols(httpProtocol).assertions(global().responseTime().max().lt(maxResponseTime));
                } else {
                    setUp(getNonAuth.injectOpen(constantUsersPerSec(totalUsers).during(durations))).protocols(httpProtocol).assertions(global().responseTime().max().lt(maxResponseTime));
                }
            }

        }

        // Set up scenarios and injections for (At once users) user type & apply assertion that maximum response time will be less than maxResponseTime(variable)
        else if(userType.equals("At once users")){
            if (requestMethod.equalsIgnoreCase("put")) {
                if (dataOfRequest.get(4) != null && !dataOfRequest.get(4).isEmpty()) {
                    setUp(putAuth.injectOpen(atOnceUsers(totalUsers))).protocols(httpProtocol).assertions(global().responseTime().max().lt(maxResponseTime));
                } else {
                    setUp(putNonAuth.injectOpen(atOnceUsers(totalUsers))).protocols(httpProtocol).assertions(global().responseTime().max().lt(maxResponseTime));
                }
            } else if (requestMethod.equalsIgnoreCase("post")) {
                if (dataOfRequest.get(4) != null && !dataOfRequest.get(4).isEmpty()) {
                    setUp(postAuth.injectOpen(atOnceUsers(totalUsers))).protocols(httpProtocol).assertions(global().responseTime().max().lt(maxResponseTime));
                } else {
                    setUp(postNonAuth.injectOpen(atOnceUsers(totalUsers))).protocols(httpProtocol).assertions(global().responseTime().max().lt(maxResponseTime));
                }
            } else if (requestMethod.equalsIgnoreCase("delete")) {
                if (dataOfRequest.get(4) != null && !dataOfRequest.get(4).isEmpty()) {
                    setUp(deleteAuth.injectOpen(atOnceUsers(totalUsers))).protocols(httpProtocol).assertions(global().responseTime().max().lt(maxResponseTime));
                } else {
                    setUp(deleteNonAuth.injectOpen(atOnceUsers(totalUsers))).protocols(httpProtocol).assertions(global().responseTime().max().lt(maxResponseTime));
                }
            } else if (requestMethod.equalsIgnoreCase("get")) {
                if (dataOfRequest.get(4) != null && !dataOfRequest.get(4).isEmpty()) {
                    setUp(getAuth.injectOpen(atOnceUsers(totalUsers))).protocols(httpProtocol).assertions(global().responseTime().max().lt(maxResponseTime));
                } else {
                    setUp(getNonAuth.injectOpen(atOnceUsers(totalUsers))).protocols(httpProtocol).assertions(global().responseTime().max().lt(maxResponseTime));
                }
            }
        }

        // Set up scenarios and injections for (rampUsers per second to) user type & apply assertion that maximum response time will be less than maxResponseTime(variable)
        else if(userType.contains("rampUsers per second to")){
            if (requestMethod.equalsIgnoreCase("put")) {
                if (dataOfRequest.get(4) != null && !dataOfRequest.get(4).isEmpty()) {
                    setUp(putAuth.injectOpen(rampUsersPerSec(totalUsers).to(numericValues).during(durations))).protocols(httpProtocol).assertions(global().responseTime().max().lt(maxResponseTime));
                } else {
                    setUp(putNonAuth.injectOpen(rampUsersPerSec(totalUsers).to(numericValues).during(durations))).protocols(httpProtocol).assertions(global().responseTime().max().lt(maxResponseTime));
                }
            } else if (requestMethod.equalsIgnoreCase("post")) {
                if (dataOfRequest.get(4) != null && !dataOfRequest.get(4).isEmpty()) {
                    setUp(postAuth.injectOpen(rampUsersPerSec(totalUsers).to(numericValues).during(durations))).protocols(httpProtocol).assertions(global().responseTime().max().lt(maxResponseTime));
                } else {
                    setUp(postNonAuth.injectOpen(rampUsersPerSec(totalUsers).to(numericValues).during(durations))).protocols(httpProtocol).assertions(global().responseTime().max().lt(maxResponseTime));
                }
            } else if (requestMethod.equalsIgnoreCase("delete")) {
                if (dataOfRequest.get(4) != null && !dataOfRequest.get(4).isEmpty()) {
                    setUp(deleteAuth.injectOpen(rampUsersPerSec(totalUsers).to(numericValues).during(durations))).protocols(httpProtocol).assertions(global().responseTime().max().lt(maxResponseTime));
                } else {
                    setUp(deleteNonAuth.injectOpen(rampUsersPerSec(totalUsers).to(numericValues).during(durations))).protocols(httpProtocol).assertions(global().responseTime().max().lt(maxResponseTime));
                }
            } else if (requestMethod.equalsIgnoreCase("get")) {
                if (dataOfRequest.get(4) != null && !dataOfRequest.get(4).isEmpty()) {
                    setUp(getAuth.injectOpen(rampUsersPerSec(totalUsers).to(numericValues).during(durations))).protocols(httpProtocol).assertions(global().responseTime().max().lt(maxResponseTime));
                } else {
                    setUp(getNonAuth.injectOpen(rampUsersPerSec(totalUsers).to(numericValues).during(durations))).protocols(httpProtocol).assertions(global().responseTime().max().lt(maxResponseTime));
                }
            }
        }
        else {
            System.out.println("Not a valid user Type");
        }
    }

    /**
     * Constructor for VertexPerformanceReports.
     * @throws IOException If an I/O error occurs.
     */
    public VertexPerformanceReports() throws IOException {
        startPerformanceReporting();
    }
}