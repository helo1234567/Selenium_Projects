package com.vaf.api;

import org.json.JSONArray;
import org.json.JSONObject;

public class helo {
    public static void main(String[] args) {
        String key = "[0].productCode";
        String apiResponse = "[{ \"productCode\": \"galaxy-z-flip4\", \"name\": \"Galaxy Z Flip4\", \"slug\": \"galaxy-z-flip4-samsung\"}]";

//System.out.print("res: " + );
        helo p = new helo();
        System.out.println(p.resolveJSONArray(apiResponse, key));
    }

    public String resolveJSONArray(String apiResponse, String key){

        if (key.charAt(0) == '['){
            String index = "";
            String newKey = "";
            Boolean isKey = false;
            char[] keyArray = key.toCharArray();
            for(int i = 1; i < keyArray.length; i++){
                if (!isKey && keyArray[i] == ']') {
                    isKey = true;
                    i = i + 1;
                    continue;
                }

                if (isKey){
                    newKey += keyArray[i];
                } else {
                    index += keyArray[i];
                }

            }

            int x = Integer.parseInt(index);
            JSONArray jsonArr = new JSONArray(apiResponse);
            Object obj = jsonArr.get(x);
//JSONObject jo = new JSONObject(obj);
            JSONObject jo = new JSONObject( obj.toString() );

            return jo.get(newKey).toString();
        }
        return "";

    }
}
