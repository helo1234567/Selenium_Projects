package com.vaf.steps;

import com.vaf.api.APIManager;
import com.vaf.utils.Assertions;
import com.vaf.utils.ExcelUtil;
import cucumber.api.java.en.And;
import io.cucumber.java.en.Then;
import io.restassured.response.Response;
//import org.json.JSONArray;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.testng.annotations.Test;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.vaf.utils.LogUtil.logInfo;

/**
 * This class contains step definitions for API testing scenarios using Cucumber.
 */
public class ApiSteps {

    APIManager apiManager = new APIManager();
    ExcelUtil excelUtil=new ExcelUtil();
    public static String configServer;
    public static Response requestResponse;
    private String previousResponse = "{}";
    private String storedResponse = "{}";


    /**
     * Sends a request with a JSON body for the specified request type, Excel key, and endpoint.
     *
     * @param requestType The type of HTTP request (e.g., GET, POST).
     * @param excelKey The key used to fetch data from the Excel sheet.
     * @param endPoint The endpoint for the API request.
     * @throws IOException If an I/O error occurs while reading data from the Excel sheet.
     */
    @Test
    @And("User sends {string} request for key {string} for endpoint {string} in json body")
    public void User_sends_request_for_key_for_endpoint_in_json_body(String requestType,String excelKey,String endPoint) throws IOException {

        ArrayList<String> requestData = (ArrayList<String>) excelUtil.getData(excelKey);
        int counter = 0;
        for (String json : requestData) {
            if (counter == 0) {
                counter++;
                continue;
            }
            if (!apiManager.ValidJson(json)) {
                logInfo("Invalid JSON"+"  :"+json);
            }
        }
        String requestBody = APIManager.autoFillResponseValues(storedResponse, requestData.get(1));
        System.out.println("Body of Request" + requestBody);
        String requestHeader = APIManager.autoFillResponseValues(storedResponse, requestData.get(2));
        System.out.println("Headers of Request" + requestHeader);
        String queryParams = APIManager.autoFillResponseValues(storedResponse, requestData.get(3));
        System.out.println("Query_params of Request" + queryParams);
        requestResponse = apiManager.simpleRequestWithJsonBody(requestBody , requestHeader, queryParams,endPoint,requestType,excelKey);
        previousResponse = requestResponse.body().asString();
        System.out.println("Response of Request" + requestResponse.body().asString());
    }

    /**
     * Sends a request with a JSON body and specified server for the given request type, Excel key, and endpoint.
     *
     * @param requestType The type of HTTP request (e.g., GET, POST).
     * @param excelKey The key used to fetch data from the Excel sheet.
     * @param endPoint The endpoint for the API request.
     * @param server The server(BaseURI) to which the request is sent.
     * @throws IOException If an I/O error occurs while reading data from the Excel sheet.
     */
    @Test
    @And("User sends {string} request for key {string} for endpoint {string} in json body with server {string}")
    public void User_sends_request_for_key_for_endpoint_in_json_body_with_server(String requestType,String excelKey,String endPoint,String server) throws IOException {

        ArrayList<String> requestData = (ArrayList<String>) excelUtil.getData(excelKey);
        int counter = 0;
        for (String json : requestData) {
            if (counter == 0) {
                counter++;
                continue;
            }
            if (!apiManager.ValidJson(json)) {
                logInfo("Invalid JSON"+"  :"+json);
            }
        }
        String requestBody = APIManager.autoFillResponseValues(storedResponse, requestData.get(1));
        System.out.println("Body of Request" + requestBody);
        String requestHeader = APIManager.autoFillResponseValues(storedResponse, requestData.get(2));
        System.out.println("Headers of Request" + requestHeader);
        String queryParameters = APIManager.autoFillResponseValues(storedResponse, requestData.get(3));
        System.out.println("Query_params of Request" + queryParameters);
        requestResponse = apiManager.serverRequestWithJsonBody(requestBody , requestHeader, queryParameters,endPoint,requestType,excelKey,server);
        previousResponse = requestResponse.body().asString();
        System.out.println("Response of Request" + requestResponse.body().asString());
    }

    /**
     * Sends a request with a URL-encoded body for the given request type, Excel key, and endpoint.
     *
     * @param requestType The type of HTTP request (e.g., GET, POST).
     * @param excelKey The key used to fetch data from the Excel sheet.
     * @param endPoint The endpoint for the API request.
     * @throws IOException If an I/O error occurs while reading data from the Excel sheet.
     */
    @Test
    @And("User sends {string} request for key {string} for endpoint {string} in urlencoded body")
    public void User_sends_request_for_key_for_endpoint_in_urlencoded_body(String requestType,String excelKey,String endPoint) throws IOException {

        ArrayList<String> requestData = (ArrayList<String>) excelUtil.getData(excelKey);
        int counter = 0;
        for (String json : requestData) {
            if (counter == 0) {
                counter++;
                continue;
            }
            if (!apiManager.ValidJson(json)) {
                logInfo("Invalid JSON"+"  :"+json);
            }
        }
        String requestBody = APIManager.autoFillResponseValues(storedResponse, requestData.get(1));
        System.out.println("Body of Request" + requestBody);
        String requestHeader = APIManager.autoFillResponseValues(storedResponse, requestData.get(2));
        System.out.println("Headers of Request" + requestHeader);
        String queryParameters = APIManager.autoFillResponseValues(storedResponse, requestData.get(3));
        System.out.println("Query_params of Request" + queryParameters);
        requestResponse = apiManager.simpleRequestWithUrlEncodedBody(requestBody , requestHeader, queryParameters,endPoint,requestType,excelKey);
        previousResponse = requestResponse.body().asString();
        System.out.println("Response of Request" + requestResponse.body().asString());
    }

    /**
     * Sends a request with a URL-encoded body and a specific server for the given request type, Excel key, endpoint, and server.
     *
     * @param requestType The type of HTTP request (e.g., GET, POST).
     * @param excelKey The key used to fetch data from the Excel sheet.
     * @param endPoint The endpoint for the API request.
     * @param server The server(BaseURI) to which the request is sent.
     * @throws IOException If an I/O error occurs while reading data from the Excel sheet.
     */
    @Test
    @And("User sends {string} request for key {string} for endpoint {string} in urlencoded body with server {string}")
    public void User_sends_request_for_key_for_endpoint_in_urlencoded_body_with_server(String requestType,String excelKey,String endPoint,String server) throws IOException {
        configServer = server;
        ArrayList<String> requestData = (ArrayList<String>) excelUtil.getData(excelKey);

        int counter = 0;

        for (String json : requestData) {
            if (counter == 0) {
                counter++;
                continue;
            }
            if (!apiManager.ValidJson(json)) {
                logInfo("Invalid JSON"+"  :"+json);
            }
        }
        String requestBody = APIManager.autoFillResponseValues(storedResponse, requestData.get(1));
        System.out.println("Body of Request" + requestBody);
        String requestHeader = APIManager.autoFillResponseValues(storedResponse, requestData.get(2));
        System.out.println("Headers of Request" + requestHeader);
        String queryParameters = APIManager.autoFillResponseValues(storedResponse, requestData.get(3));
        System.out.println("Query_params of Request" + queryParameters);
        requestResponse = apiManager.serverRequestWithUrlEncodedBody(requestBody , requestHeader, queryParameters,endPoint,requestType,excelKey,server);
        previousResponse = requestResponse.body().asString();
        System.out.println("Response of Request" + requestResponse.body().asString());
    }

    /**
     * Stores a key-value pair from a JSON response.
     *
     * @param keyPath The key path to extract the value from the JSON response.
     */
    @Then("Store key value pair of {string} this path")
    public void Store_key_value_pair_of_this_path(String keyPath)  {
        // Extract a value from a JSON response using the given key path
        String keyValue = APIManager.extractValueFromJson(requestResponse.body().asString(), keyPath);

        // Parse the previousResponseJSON
        org.json.JSONObject previousResponseJson = new org.json.JSONObject(storedResponse);

        // Split the key path to obtain the actual key
        String[] keys = keyPath.split("\\.");
        String actualKey = keys[keys.length - 1];

        // Update the JSON object with the new key-value pair
        previousResponseJson.put(actualKey, keyValue);

        // Convert the 'previousResponseJson' object back to a string and store it in 'storedResponse'
        storedResponse = previousResponseJson.toString();
        System.out.println("Stored_Response"+ storedResponse);
    }

    /**
     * Validates that the response matches the JSON stored in the provided file.
     *
     * @param filePath The path to the file containing the JSON to compare the response against.
     * @throws IOException If an I/O exception occurs during file reading.
     */
    @Then("validate that response will be same as stored in {string}")
    public void validate_that_response_will_be_same_as_stored_in(String filePath) throws IOException {
        // Initialize JSON parser and stored response object
        JSONParser jsonParser = new JSONParser();
        Object storedResponse = null;

        // Parse the stored response JSON from the provided file
        try (FileReader reader = new FileReader(ExcelUtil.getFileFromResourceFolder(filePath))) {
            storedResponse = jsonParser.parse(reader);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Parse the actual response JSON
        JSONParser responseParser = new JSONParser();
        Object responseObject;

        try {
            responseObject = responseParser.parse(previousResponse);
        } catch (ParseException e) {
            e.printStackTrace();
            responseObject = null;
        }

        // Assertions to compare the actual response with the stored response
        Assertions.assertTrue(responseObject != null && responseObject.equals(storedResponse),"Response Matched or Not",null);

        // Compare the actual response with the stored response
        if (responseObject != null && responseObject.equals(storedResponse)) {
            logInfo("Response matches the stored response.");
            System.out.println("Response matches the stored response.");
        } else {
            logInfo("Response does not match the stored response.");
            System.out.println("Response does not match the stored response.");
        }
    }

    /**
     * Sends multiple requests with varying data based on placeholders in JSON body.
     *
     * @param requestType       The type of request (e.g., GET, POST, etc.).
     * @param compoundKey       The compound key containing sheet names and data keys.
     * @param endPoint          The endpoint URL for the API request.
     * @throws IOException      If an I/O exception occurs during data retrieval or API request.
     */
    @Test
    @And("user send multiple {string} requests for Keys {string} for endpoint {string} in json body")
    public void user_send_multiple_requests_for_Keys_for_endpoint_in_json_body(String requestType, String compoundKey, String endPoint) throws IOException {
        String requestDataSheetName = compoundKey.split("[.]")[0];
        String iterativeDataSheetName = compoundKey.split("[.]")[1];
        String excelDataKey = compoundKey.split("[.]")[2];
        ArrayList<String> requestData = (ArrayList<String>) excelUtil.getData(requestDataSheetName + "." + excelDataKey);
        int rowCount = (int) ExcelUtil.getRowCount(iterativeDataSheetName);
        for (int i = 0; i < rowCount; i++) {
            ArrayList<String> modifiedData = new ArrayList<>();

            for (String json : requestData) {
                Pattern pattern = Pattern.compile("#\\{([^}]+)\\}"); // Regular expression pattern to match #{placeholder}
                Matcher matcher = pattern.matcher(json);

                while (matcher.find()) {
                    String placeholder = matcher.group(1); // Extracting the placeholder without #{}
                    List<String> values = ExcelUtil.valuesFor(iterativeDataSheetName + "." + placeholder);
                    if (!values.isEmpty() && i < values.size()) {
                        String replacement = values.get(i); // Get the value corresponding to the current index
                        json = json.replaceAll("#\\{" + placeholder + "\\}", replacement);
                    }
                }

                modifiedData.add(json);
            }

            requestResponse = apiManager.simpleRequestWithJsonBody(modifiedData.get(1), modifiedData.get(2), modifiedData.get(3), endPoint, requestType,requestDataSheetName + "." + excelDataKey);
            previousResponse = requestResponse.body().asString();
            System.out.println("Response of Request: " + previousResponse);
        }
    }


    /**
     * Sends multiple requests with varying data based on placeholders in JSON body to the specified endpoint using a server.
     *
     * @param requestType       The type of request (e.g., GET, POST, etc.).
     * @param compoundKey       The compound key containing sheet names and data keys.
     * @param endPoint          The endpoint URL for the API request.
     * @param server            The server(BaseURI) to send the request to.
     * @throws IOException      If an I/O exception occurs during data retrieval or API request.
     */
    @Test
    @And("user send multiple {string} requests for Keys {string} for endpoint {string} in json body with server {string}")
    public void user_send_multiple_requests_for_Keys_for_endpoint_in_json_body_with_server(String requestType, String compoundKey, String endPoint,String server) throws IOException {
        String requestDataSheetName = compoundKey.split("[.]")[0];
        String iterativeDataSheetName = compoundKey.split("[.]")[1];
        String excelDataKey = compoundKey.split("[.]")[2];
        ArrayList<String> requestData = (ArrayList<String>) excelUtil.getData(requestDataSheetName + "." + excelDataKey);
        int rowCount = (int) ExcelUtil.getRowCount(iterativeDataSheetName);

        for (int i = 0; i < rowCount; i++) {
            ArrayList<String> modifiedData = new ArrayList<>();

            for (String json : requestData) {
                Pattern pattern = Pattern.compile("#\\{([^}]+)\\}"); // Regular expression pattern to match #{placeholder}
                Matcher matcher = pattern.matcher(json);

                while (matcher.find()) {
                    String placeholder = matcher.group(1); // Extracting the placeholder without #{}
                    List<String> values = ExcelUtil.valuesFor(iterativeDataSheetName + "." + placeholder);
                    if (!values.isEmpty() && i < values.size()) {
                        String replacement = values.get(i); // Get the value corresponding to the current index
                        json = json.replaceAll("#\\{" + placeholder + "\\}", replacement);
                    }
                }

                modifiedData.add(json);
            }

            requestResponse = apiManager.serverRequestWithJsonBody(modifiedData.get(1), modifiedData.get(2), modifiedData.get(3), endPoint, requestType,requestDataSheetName + "." + excelDataKey,server);
            previousResponse = requestResponse.body().asString();
            System.out.println("Response of Request: " + previousResponse);
        }
    }

    /**
     * Sends multiple requests with varying data based on placeholders in URL-encoded body.
     *
     * @param requestType       The type of request (e.g., GET, POST, etc.).
     * @param compoundKey       The compound key containing sheet names and data keys.
     * @param endPoint          The endpoint URL for the API request.
     * @throws IOException      If an I/O exception occurs during data retrieval or API request.
     */
    @Test
    @And("user send multiple {string} requests for Keys {string} for endpoint {string} in urlencoded body")
    public void user_send_multiple_requests_for_Keys_for_endpoint_in_urlencoded_body(String requestType, String compoundKey, String endPoint) throws IOException {
        String requestDataSheetName = compoundKey.split("[.]")[0];
        String iterativeDataSheetName = compoundKey.split("[.]")[1];
        String excelDataKey = compoundKey.split("[.]")[2];
        ArrayList<String> requestData = (ArrayList<String>) excelUtil.getData(requestDataSheetName + "." + excelDataKey);
        int rowCount = (int) ExcelUtil.getRowCount(iterativeDataSheetName);

        for (int i = 0; i < rowCount; i++) {
            ArrayList<String> modifiedData = new ArrayList<>();

            for (String json : requestData) {
                Pattern pattern = Pattern.compile("#\\{([^}]+)\\}"); // Regular expression pattern to match #{placeholder}
                Matcher matcher = pattern.matcher(json);

                while (matcher.find()) {
                    String placeholder = matcher.group(1); // Extracting the placeholder without #{}
                    List<String> values = ExcelUtil.valuesFor(iterativeDataSheetName + "." + placeholder);
                    if (!values.isEmpty() && i < values.size()) {
                        String replacement = values.get(i); // Get the value corresponding to the current index
                        json = json.replaceAll("#\\{" + placeholder + "\\}", replacement);
                    }
                }

                modifiedData.add(json);
            }

            requestResponse = apiManager.simpleRequestWithUrlEncodedBody(modifiedData.get(1), modifiedData.get(2), modifiedData.get(3), endPoint, requestType,requestDataSheetName + "." + excelDataKey);
            previousResponse = requestResponse.body().asString();
            System.out.println("Response of Request: " + previousResponse);
        }
    }

    /**
     * Sends multiple requests with varying data based on placeholders in URL-encoded body to the specified endpoint using a server.
     *
     * @param requestType       The type of request (e.g., GET, POST, etc.).
     * @param compoundKey       The compound key containing sheet names and data keys.
     * @param endPoint          The endpoint URL for the API request.
     * @param server            The server to send the request to.
     * @throws IOException      If an I/O exception occurs during data retrieval or API request.
     */
    @Test
    @And("user send multiple {string} requests for Keys {string} for endpoint {string} in urlencoded body with server {string}")
    public void user_send_multiple_requests_for_Keys_for_endpoint_in_urlencoded_body_with_server(String requestType, String compoundKey, String endPoint,String server) throws IOException {
        String requestDataSheetName = compoundKey.split("[.]")[0];
        String iterativeDataSheetName = compoundKey.split("[.]")[1];
        String excelDataKey = compoundKey.split("[.]")[2];
        ArrayList<String> data = (ArrayList<String>) excelUtil.getData(requestDataSheetName + "." + excelDataKey);
        int rowCount = (int) ExcelUtil.getRowCount(iterativeDataSheetName);

        for (int i = 0; i < rowCount; i++) {
            ArrayList<String> modifiedData = new ArrayList<>();

            for (String json : data) {
                Pattern pattern = Pattern.compile("#\\{([^}]+)\\}"); // Regular expression pattern to match #{placeholder}
                Matcher matcher = pattern.matcher(json);

                while (matcher.find()) {
                    String placeholder = matcher.group(1); // Extracting the placeholder without #{}
                    List<String> values = ExcelUtil.valuesFor(iterativeDataSheetName + "." + placeholder);
                    if (!values.isEmpty() && i < values.size()) {
                        String replacement = values.get(i); // Get the value corresponding to the current index
                        json = json.replaceAll("#\\{" + placeholder + "\\}", replacement);
                    }
                }

                modifiedData.add(json);
            }

            requestResponse = apiManager.serverRequestWithUrlEncodedBody(modifiedData.get(1), modifiedData.get(2), modifiedData.get(3), endPoint, requestType,requestDataSheetName + "." + excelDataKey,server);
            previousResponse = requestResponse.body().asString();
            System.out.println("Response of Request: " + previousResponse);
        }
    }
}
