package com.vaf.steps;

import com.vaf.web.UIManager;
import cucumber.api.java.en.When;
import org.testng.annotations.Test;
import java.util.Arrays;
import java.util.List;

public class AccessibilitySteps {

//    static UIManager mgr;

//    @Test
//    @When("User navigates to {string}")
//    public void User_navigates_to(String url) {
//        mgr = new UIManager();
//        mgr.accessibilityStartSession(url);
//    }
//
//    @Test
//    @When("Check for accessibility issues by excluding following rules {string}")
//    public void excluding_Rules(String rules) {
//        List<String> excludedRules = Arrays.asList(rules.split(","));
//        mgr.excludeRulesAccessibilityWithCustomReport(excludedRules);
//    }
//
//    @Test
//    @When("Check for any accessibility issue")
//    public void anyAccessibilityIssue() {
//        mgr.anyAccessibilityWithCustomReport();
//    }
//
//    @Test
//    @When("Check for accessibility issues by excluding following elements {string}")
//    public void excludingElements(String elements) {
//        List<String> excludedRules = Arrays.asList(elements.split(","));
//        mgr.excludingElementsAccessibilityWithCustomReport(excludedRules);
//    }
//
//    @Test
//    @When("Check for accessibility issues by excluding this element {string}")
//    public void excludingElement(String elements) {
//        mgr.excludingSpecificElement(elements);
//    }

}
