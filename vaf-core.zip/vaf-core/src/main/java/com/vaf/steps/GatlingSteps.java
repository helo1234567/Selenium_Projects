package com.vaf.steps;

import com.vaf.api.APIManager;
import com.vaf.performance.Engine;
import com.vaf.performance.VertexPerformanceReports;
import com.vaf.utils.ExcelUtil;
import com.vaf.utils.ReportsDashboardutil;
import cucumber.api.java.en.When;
import io.cucumber.java.en.Then;
import org.json.JSONObject;
import java.io.IOException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class GatlingSteps {
    // Define static variables
    public static String typeOfRequest;
    public static int totalNoOfUsers;
    public static int timeDuration;
    public static int numericValue;
    public static String apiEndpoint;
    public static String keyOfExcel;
    public static String typeOfBody;
    public static String excelBody;
    public static String typeOfUsers;
    public static String nameOfRequest;
    public static String excelHeader;
    public static String excelQueryParameters;
    private String responseOfPreviousRequest = "{}"; // Stores specific keyValue pairs from JSON response
    public static int loops;
    ExcelUtil excelUtil = new ExcelUtil(); // Create Object of ExcelUtil Class
    ReportsDashboardutil reportsDashboardutil = new ReportsDashboardutil(); // Create Object of ReportsDashboardutil Class
    /**
     * Sets the maximum response time for performance testing.
     *
     * @param responseTime The maximum response time to set.
     */
    @When("set performance testing response time to <{int}>")
    public void set_performance_testing_response_time_to(Integer responseTime){
        //Set value of maxResponseTime in VertexPerformanceReports class
        VertexPerformanceReports.maxResponseTime = responseTime;
    }

    /**
     * Send a performance testing request.
     *
     * @param requestType    Type of the request(Get,Post,Put,Delete).
     * @param requestName    Name of the request.
     * @param excelKey       Key for fetching request data from Excel.
     * @param endPoint       API endpoint.
     * @param numberOfUsers  Number of users.
     * @param usersType      Type of users(rampUsers,constant user per second,At once users,rampUsers per second to integer)
     * @param duration       Duration of the test.
     * @param loop           Number of loops(how many times you want to repeat the same step)
     * @param bodyType       Type of request body(json,urlEncoded)
     * @throws IOException If an I/O error occurs.
     */
    @When("user sends {string} {string} for key {string} at endpoint {string} with <{int}> {string} during <{int}> seconds for <{int}> time in {string} body")
    public void user_sends_for_key_at_endpoint_with_during_seconds_for_time_in_body(String requestType,String requestName,String excelKey,String endPoint,int numberOfUsers,String usersType,int duration,int loop,String bodyType) throws IOException {
        //Fetching request data from ExcelUtil class by passing excelKey
        ArrayList<String> requestData = (ArrayList<String>) excelUtil.getPerformanceData(excelKey);
        // Compile a regular expression pattern to match the format "rampUsers per second to <number>"
        Pattern pattern = Pattern.compile("rampUsers per second to (\\d+)");
        // Create a Matcher object to search for the compiled pattern within the 'usersType' string
        Matcher matcher = pattern.matcher(usersType);
        // Check if the pattern matches within the 'usersType' string
        if (matcher.find()) {
            // Extract the numeric value from the first capturing group in the pattern
            String numericValueString = matcher.group(1);
            // Convert the extracted string to an integer
            numericValue = Integer.parseInt(numericValueString);

            // Display the extracted numeric value
            System.out.println("Extracted numeric value: " + numericValue);
        } else {
            // If no match is found, indicate that no numeric value was found
            System.out.println("No numeric value found in the string.");
        }
            // Autofill any specific Response value in Body,Header and Query parameters
        excelBody = APIManager.autoFillResponseValues(responseOfPreviousRequest, requestData.get(1));
        excelHeader = APIManager.autoFillResponseValues(responseOfPreviousRequest, requestData.get(2));
        excelQueryParameters = APIManager.autoFillResponseValues(responseOfPreviousRequest, requestData.get(3));
            // Assign values to Static variables defined in classLevel
        typeOfRequest = requestType;
        totalNoOfUsers = numberOfUsers;
        timeDuration = duration;
        apiEndpoint = endPoint;
        keyOfExcel=excelKey;
        loops=loop;
        typeOfBody=bodyType;
        nameOfRequest=requestName;
        typeOfUsers=usersType;
        //Call gattlingConfig() method from Engine class
        Engine.gattlingConfig();
        //Call generateDashboard() method from ReportsDashboardutil class
        reportsDashboardutil.generateDashboard();
    }


    /**
     * Stores key-value pairs from JSON response.
     *
     * @param keyPath Path to the desired key.
     */
    @Then("Store key value pairs of {string} this path")
    public void store_key_value_pairs_of_this_path(String keyPath)  {
        // Extract a value from a JSON response using the given key path
        String keyValue = APIManager.extractValueFromJson(VertexPerformanceReports.sessionResponse, keyPath);
        // Parse the previous response JSON
        JSONObject previousResponseJson = new JSONObject(responseOfPreviousRequest);
        // Split the key path to obtain the actual key
        String[] keys = keyPath.split("\\.");
        String actualKey = keys[keys.length - 1];
        // Update the JSON object with the new key-value pair
        previousResponseJson.put(actualKey, keyValue);
        // Update the responseOfPreviousRequest with the updated JSON
        responseOfPreviousRequest = previousResponseJson.toString();
        // Display the stored response
        System.out.println("Stored Response"+responseOfPreviousRequest);
    }
}
