package com.vaf.steps;

import com.vaf.performance.Engine;
import cucumber.api.java.en.When;

public class GatlingSteps {

    public static String Request;
    public static int Users;
    public static int RampUP;
    public static String Endpoint;
    public static String Keys;

    public static int Loops;
    @When("user sends {string} request for key {string} at endpoint {string} with <{int}> users during <{int}> seconds for <{int}> time")
    public void Jmeter(String request,String key1,String endpoint,int users,int rampUP,int loop) {

        Request = request;
        Users = users;
        RampUP = rampUP;
        Endpoint = endpoint;
        Keys=key1;
        Loops=loop;
        Engine.gattlingConfig();

    }
}
