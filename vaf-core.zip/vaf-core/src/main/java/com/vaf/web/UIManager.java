package com.vaf.web;

import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.time.Duration;
import java.util.*;
import java.util.List;
import com.deque.html.axecore.extensions.WebDriverExtensions;
import com.deque.html.axecore.results.CheckedNode;
import com.deque.html.axecore.results.Results;
import com.deque.html.axecore.results.Rule;
import com.deque.html.axecore.selenium.AxeBuilder;
import com.vaf.utils.Assertions;
import com.vaf.utils.ConfigUtil;
import org.openqa.selenium.*;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.vaf.enumerations.BrowserType;
import com.paulhammant.ngwebdriver.NgWebDriver;
import com.vaf.utils.LogUtil;
import org.testng.Assert;

public class UIManager {
    public enum LocatorType {
        xpath, cssSelector, cssId, cssClass,
    }

    private Duration timeOut = Duration.ofMillis(40000);

    public WebDriver driver;
    Browser browser = new Browser();
    private NgWebDriver ngWebDriver = null;
    public static String currentBrowser = "";

    public UIManager() {
        UIManager.currentBrowser = ConfigUtil.CONFIG_GET_STRING("Browser").toUpperCase();
        String browserType = ConfigUtil.CONFIG_GET_STRING("Browser").toUpperCase();
        boolean headless = Boolean.parseBoolean(ConfigUtil.CONFIG_GET_STRING("headless"));
        this.driver = browser.getInstance(BrowserType.valueOf(browserType), headless);

    }
    public UIManager(BrowserType browserType, boolean headless) {
        String webBrowser = browserType.toString();
        this.driver = browser.getInstance(BrowserType.valueOf(webBrowser), headless);
    }

    public void startSession(String url) {
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
        driver.get(url);
    }

    public void accessibilityStartSession(String url) {
        driver.get(url);
    }

    public void endSession() {
        driver.quit();
    }

    public void waitImplicit(Integer duration) {
        driver.manage().timeouts().implicitlyWait(Duration.ofMillis(duration));
    }

    public void waitForAngular() {
        ngWebDriver.waitForAngularRequestsToFinish();
    }

    public WebDriverWait explicitWait() {
        return new WebDriverWait(driver, timeOut);
    }

    public void waitUntilVisible(String locator) {
        this.waitUntilVisible(locator, LocatorType.xpath);
    }

    public void waitUntilVisible(String locator, LocatorType locatorType) {
        WebElement we = this.elementBy(locatorType, locator);
        this.waitUntilVisible(we);
    }

    public void waitUntilVisible(WebElement element) {
        explicitWait().until(ExpectedConditions.visibilityOf(element));
    }
    public WebElement elementBy(LocatorType type, String locator) {
        switch (type) {
            case cssSelector:
                return driver.findElement(By.cssSelector(locator));
            case cssId:
                return driver.findElement(By.id(locator));
            case cssClass:
                return driver.findElement(By.className(locator));
            default:
                return driver.findElement(By.xpath(locator));
        }
    }


    public void waitToVisible(String waitLocator, LocatorType locatorType) throws InterruptedException {
        boolean terminate = false;
        WebElement elementVisible = null;
        do {
            try {
                elementVisible = this.elementBy(locatorType, waitLocator);

                if (elementVisible.isDisplayed()) {
                    System.out.println("Element is now visible.");
                    terminate = true; // Exit the loop when the element is displayed
                } else {
                    System.out.println("Element is not visible yet. Waiting...");
                    Thread.sleep(1); // Wait for 1 second before checking again
                }
            } catch (NoSuchElementException e) {
                System.out.println("Element not found. Waiting...");
                Thread.sleep(1); // Wait for 1 second before checking again
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        } while (!terminate);
    }

    public void hoverAndClick(String hoverLocator, String clickLocator) {
        this.hoverAndClick(hoverLocator, clickLocator, LocatorType.xpath);
    }

    public void hoverAndClick(String hoverLocator, String clickLocator, LocatorType locatorType) {
        WebElement hoverElement = this.elementBy(locatorType, hoverLocator);

        // Instantiate Action Class
        Actions actions = new Actions(driver);

        // Mouse hover menuOption 'Music'
        actions.moveToElement(hoverElement).perform();

        this.waitUntilVisible(clickLocator);

        WebElement clickElement = this.elementBy(locatorType, clickLocator);

        // Mouse hover menuOption 'Rock'
        actions.moveToElement(clickElement).perform();

        // Click on the element
        clickElement.click();
    }


    public void hoverAndClick(String hoverLocator, String clickLocator, LocatorType hoverLocatorType, LocatorType clickLocatorType) {

        WebElement hoverElement = this.elementBy(hoverLocatorType, hoverLocator);

//		this.hoverAndClick(hoverElement, clickElement);

        // Instantiate Action Class
        Actions actions = new Actions(driver);

        // Mouse hover menuOption 'Music'
        actions.moveToElement(hoverElement).perform();

        this.waitUntilVisible(clickLocator);

        WebElement clickElement = this.elementBy(clickLocatorType, clickLocator);

        // Mouse hover menuOption 'Rock'
        actions.moveToElement(clickElement).perform();

        // Click on the element
        clickElement.click();
    }

    public void hover(String hoverLocator) {
        this.hover(hoverLocator, LocatorType.xpath);
    }

    public void hover(String hoverLocator, LocatorType locatorType) {
        WebElement hoverElement = this.elementBy(locatorType, hoverLocator);

        // Instantiate Action Class
        Actions actions = new Actions(driver);
        this.waitUntilVisible(hoverLocator);
        // Mouse hover menuOption 'Music'
        actions.moveToElement(hoverElement).perform();


    }

    public void hoverAndClick(WebElement hoverElement, WebElement clickElement) {
        // Instantiate Action Class
        Actions actions = new Actions(driver);

        // Mouse hover menuOption 'Music'
        actions.moveToElement(hoverElement).perform();

        this.waitUntilVisible(clickElement);

        // Mouse hover menuOption 'Rock'
        actions.moveToElement(clickElement).perform();

        // Click on the element
        clickElement.click();
    }

    public void hover(WebElement hoverElement) {
        // Instantiate Action Class
        Actions actions = new Actions(driver);

        // Mouse hover menuOption 'Music'
        actions.moveToElement(hoverElement).perform();

    }
    public void click(String locator) {
        this.click(locator, LocatorType.xpath);
    }

    public void click(String locator, LocatorType locatorType) {
        WebElement we = this.elementBy(locatorType, locator);
        this.waitUntilVisible(we);
        this.click(we);
    }

    public void clearText(String locator, LocatorType locatorType) {
        WebElement we = this.elementBy(locatorType, locator);
        this.waitUntilVisible(we);
        we.click();
        we.clear();
    }


    public void click(WebElement element) {
        explicitWait().until(ExpectedConditions.elementToBeClickable(element));
        element.click();
    }

    public void doubleClick(String locator, LocatorType locatorType) {
        Actions actions = new Actions(driver);
        WebElement we = this.elementBy(locatorType, locator);
        this.waitUntilVisible(we);
        actions.doubleClick(we).build().perform();
    }

    public void pressEnter(String locator, LocatorType locatorType) {
        WebElement we = this.elementBy(locatorType, locator);
        this.waitUntilVisible(we);
        we.sendKeys(Keys.ENTER);
    }

    public void fillTextField(String locator, String text) throws InterruptedException {
        this.fillTextField(locator, text, LocatorType.xpath);
    }

    public void fillTextField(String locator, String text, LocatorType locatorType) throws InterruptedException {
        WebElement we = this.elementBy(locatorType, locator);
        this.fillTextField(we, text);
    }


    public void fillTextField(String locator, Keys key, LocatorType locatorType) {
        WebElement we = this.elementBy(locatorType, locator);
        this.fillTextField(we, key);
    }

    public void fillTextField(WebElement element, String text) throws InterruptedException {
        this.waitUntilVisible(element);
        element.sendKeys(text);
    }

    public void fillTextField(WebElement element, Keys key) {
        element.sendKeys(key);
    }

    // Dropdown

    public void selectDropdownOption(String dropdownLocator, String clickLocator) {
        this.selectDropdownOption(dropdownLocator, clickLocator, LocatorType.xpath);
    }

    public void selectDropdownOption(String dropdownLocator, String clickLocator, LocatorType locatorType) {
        WebElement selectDropdown = this.elementBy(locatorType, dropdownLocator);
        WebElement selectElement = this.elementBy(locatorType, clickLocator);
        String interactValue = selectElement.getText();
        this.selectDropdownOption(selectDropdown, selectElement, interactValue);

    }

    public void selectDropdownOption(String dropdownLocator, String clickLocator, LocatorType dropDownLocatorType, LocatorType clickLocatorType) {
        WebElement selectDropdown = this.elementBy(dropDownLocatorType, dropdownLocator);
        WebElement selectElement = this.elementBy(clickLocatorType, clickLocator);
        String interactValue = selectElement.getText();
        this.selectDropdownOption(selectDropdown, selectElement, interactValue);

    }


    public void selectDropdownOption(WebElement dropdownElement, WebElement clickElement, String dropDownValue) {
        explicitWait().until(ExpectedConditions.visibilityOf(dropdownElement));

        Select select = new Select(dropdownElement);

        explicitWait().until(ExpectedConditions.visibilityOf(clickElement));

        select.selectByVisibleText(dropDownValue);
    }



    public void scroll(WebElement element) {
        this.scroll(element, true);
    }

    public void scroll(WebElement element, boolean scrollIntoView) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollIntoView(" + (scrollIntoView ? "true" : "false") + ")", element);
    }

    public void scroll(String element) {
        this.scroll(element, true);
    }

    public void scroll(String element, LocatorType locatorType, boolean scrollIntoView) {
        WebElement scrollLocator = this.elementBy(locatorType, element);
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollIntoView(" + (scrollIntoView ? "true" : "false") + ")", scrollLocator);
    }

    public void scroll(String element, boolean scrollIntoView) {

        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollIntoView(" + (scrollIntoView ? "true" : "false") + ")", element);
    }

    public void scrollAndClick(String element, String element2, LocatorType locatorType) {
        this.scrollAndClick(element, element2, locatorType, false);
    }

    public void scrollAndClick(String element, String element2, LocatorType locatorType, LocatorType locatorType1) {
        this.scrollAndClick(element, element2, locatorType, locatorType1, false);
    }

    public void scrollAndClick(String element, String element2, LocatorType locatorType, boolean scrollIntoView) {
        WebElement we = this.elementBy(locatorType, element);
        WebElement we1 = this.elementBy(locatorType, element2);
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollIntoView(" + (scrollIntoView ? "true" : "false") + ")", we);
        we.click();
    }

    public void scrollAndClick(WebElement element, WebElement element2, boolean scrollIntoView) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollIntoView(" + (scrollIntoView ? "true" : "false") + ")", element);
        waitUntilVisible(element2);
        element2.click();
    }

    public void scrollAndClick(String element, String element2, LocatorType locatorType, LocatorType locatorType1, boolean scrollIntoView) {
        WebElement we = this.elementBy(locatorType, element);
        WebElement we1 = this.elementBy(locatorType1, element2);
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollIntoView(" + (scrollIntoView ? "true" : "false") + ")", we);
        we1.click();
    }


    public void navigateTo(String address) {
        driver.navigate().to(address);
    }

    public void navigateBack() {
        driver.navigate().back();
    }

    public void pageRefresh() {
        driver.navigate().refresh();
    }

    public void navigateForward() {
        driver.navigate().forward();
    }

    public String fetchBase64Screenshot() {
        return ((TakesScreenshot) driver).getScreenshotAs(OutputType.BASE64);
    }

    public void logScreenshot(String message) {
        String screenshot = fetchBase64Screenshot();
        LogUtil.logInfo(screenshot, message);
    }

    public void logScreenshot() {
        logScreenshot("Attached Screenshot");
    }


    public static void logInfo(String value) {
        LogUtil.logInfo(value);
    }

    public String getTitle() {
        return driver.getTitle();
    }

    public String getURL() {
        return driver.getCurrentUrl();
    }

    public String getText(WebElement element) {
        return element.getText();
    }
    public String getText(String locator) {
        return this.getText(locator, LocatorType.xpath);

    }
    public String getText(String locator, LocatorType locatorType) {
        WebElement we = this.elementBy(locatorType, locator);
        return we.getText();
    }

    public void switchToFrame(String locator) {
        switchToFrame(locator, LocatorType.xpath);
    }

    public void switchToFrame(String locator, LocatorType locatorType) {
        WebElement we = this.elementBy(locatorType, locator);
        switchToFrame(we);
    }

    public void switchToFrame(WebElement frameElement) {
        driver.switchTo().frame(frameElement);
    }

    public void switchToFrame(int index) {
        driver.switchTo().frame(index);
    }

    public void switchToParentFrame() {
        driver.switchTo().parentFrame();
    }

    public void switchToOutOfFrame() {
        driver.switchTo().defaultContent();
    }

    public void maximizeBrowser() {
        driver.manage().window().maximize();
    }

    public void minimizeBrowser() {
        driver.manage().window().minimize();
    }

    public void switchToTab(int tabIndex) {
        Set<String> windowHandles = driver.getWindowHandles();
        List<String> windowHandlesList = new ArrayList<>(windowHandles);
        driver.switchTo().window(windowHandlesList.get(tabIndex));
    }

    public String getAttribute(String locator, String attributeName) {
        return getAttribute(locator, attributeName, LocatorType.xpath);
    }

    public String getAttribute(String locator, String attributeName, LocatorType locatorType) {
        WebElement element = elementBy(locatorType, locator);
        return element.getAttribute(attributeName);
    }
    public String getAttribute(WebElement element, String attributeName) {
        return element.getAttribute(attributeName);
    }

    public boolean isDisplayed(String locator) {
        return isDisplayed(locator, LocatorType.xpath);
    }

    public boolean isDisplayed(String locator, LocatorType locatorType) {
        WebElement we = elementBy(locatorType, locator);
        return isDisplayed(we);
    }

    public boolean isDisplayed(WebElement element) {
        try {
            explicitWait().until(ExpectedConditions.visibilityOf(element));
            return true;
        } catch (TimeoutException e) {
            return false;
        }
    }

    public boolean isEnabled(String locator) {
        return isEnabled(locator, LocatorType.xpath);
    }

    public boolean isEnabled(String locator, LocatorType locatorType) {
        WebElement element = elementBy(locatorType, locator);
        return element.isEnabled();
    }

    public boolean isEnabled(WebElement element) {
        return element.isEnabled();
    }

    public boolean isEnabled(By by) {
        WebElement element = driver.findElement(by);
        return element.isEnabled();
    }

    public boolean isSelected(String locator) {
        return this.isSelected(locator, LocatorType.xpath);
    }

    public boolean isSelected(String locator, LocatorType locatorType) {
        WebElement element = this.elementBy(locatorType, locator);
        return element.isSelected();
    }

    public boolean isSelected(WebElement element) {
        return element.isSelected();
    }

    public boolean isSelected(String locator, WebElement element) {
        return element.isSelected();
    }


    public void uploadFileFromSource(String URI_OF_File, String Locator, LocatorType locatorType) throws InterruptedException {

        WebElement file = this.elementBy(locatorType, Locator);
        file.click();

        try {
            Robot selector = new Robot();
            selector.delay(2000);
            StringSelection ss = new StringSelection(URI_OF_File);
            Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);

            //now perfrom ctrl v funtion on keyboard
            selector.keyPress(KeyEvent.VK_CONTROL);//press control key
            selector.keyPress(KeyEvent.VK_V);//press V
            //now release the key

            selector.keyRelease(KeyEvent.VK_CONTROL);
            selector.keyRelease(KeyEvent.VK_V);

            //now press enter
            selector.keyPress(KeyEvent.VK_ENTER);
            selector.keyRelease(KeyEvent.VK_ENTER);

        } catch (Throwable T) {
            System.out.println(T.getMessage());
            System.out.println(T.getCause());
            Thread.sleep(8000);

        }
    }

    public void openNewWindow(String URL) throws InterruptedException {

        ((JavascriptExecutor) driver).executeScript("window.open()");
        driver.switchTo().newWindow(WindowType.WINDOW);
        driver.get(URL);
    }


    public void openInAnyDimension(int row, int col) {
        driver.manage().window().setSize(new Dimension(row, col));
    }


    public void acceptAlert() {
        Alert alert = driver.switchTo().alert();
        alert.accept();
    }

    public void rejectAlert() {
        Alert alert = driver.switchTo().alert();
        alert.dismiss();
    }

    public void alertTextHandler(String Text) {
        Alert modalDialog = driver.switchTo().alert();
        modalDialog.sendKeys(Text);
        modalDialog.accept();
        driver.switchTo().defaultContent();
    }

    public void alertGetTextHandler(String text) {
        Alert modalDialog = driver.switchTo().alert();
        String store = modalDialog.getText();

        Assert.assertEquals(text, store);
        modalDialog.accept();
        driver.switchTo().defaultContent();
    }

    public void positiveCheck(String alertLocator, LocatorType locatorType) {
        WebElement Button = this.elementBy(locatorType, alertLocator);
        Assert.assertTrue(Button.isSelected());
    }

    public void negativeCheck(String alertLocator, LocatorType locatorType) {
        WebElement Button = this.elementBy(locatorType, alertLocator);

        Assert.assertTrue(!Button.isSelected());

    }


    public void dragAble(String Locator, LocatorType locatorType) {
        WebElement Drag_Handler = this.elementBy(locatorType, Locator);

        JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
        String is_Dragg_Able = (String) jsExecutor.executeScript(
                "return arguments[0].getAttribute('draggable');", Drag_Handler);

        Assert.assertTrue((is_Dragg_Able != null && is_Dragg_Able.equals("true")));

    }

    public void dropAble(String Locator, LocatorType locatorType) {
        WebElement Drop_Handler = this.elementBy(locatorType, Locator);

        JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
        String is_Drop_Able = (String) jsExecutor.executeScript(
                "return arguments[0].getAttribute('dropable');", Drop_Handler);

        Assert.assertTrue((is_Drop_Able != null && is_Drop_Able.equals("true")));


    }

    public void sidebarScroller(String pixels) {
        JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
        jsExecutor.executeScript("window.scrollBy(0, " + pixels + ");");

    }

    public void openInNewTab(String Locator, LocatorType Type) {
        WebElement element_Holder = this.elementBy(Type, Locator);
        Actions actions = new Actions(driver);
        actions.keyDown(Keys.CONTROL).click(element_Holder).keyUp(Keys.CONTROL).perform();
    }

    public void anyAccessibilityWithCustomReport() {
        // Analyze the page creating a new AxeBuilder
        Results axeResult = new AxeBuilder().analyze(driver);
        // Assert the page has no violations and if it has add the custom report
        Assertions.assertTrue(axeResult.violationFree(), buildCustomReport(axeResult));

    }

    public static void checkAccessibilityRecursive(WebDriver driver) {
        // Get all iframes on the current page
        List<WebElement> iframes = driver.findElements(By.tagName("iframe"));

        // Iterate through iframes
        for (WebElement iframe : iframes) {
            driver.switchTo().frame(iframe); // Switch to the current iframe

            // Include aXe JavaScript library in the iframe
            String axeScript = "var script = document.createElement('script'); script.src = 'https://cdnjs.cloudflare.com/ajax/libs/axe-core/4.2.1/axe.min.js'; document.head.appendChild(script);";
            ((JavascriptExecutor) driver).executeScript(axeScript);

            // Run aXe accessibility checks in the current iframe
            Results axeResult = new AxeBuilder().analyze(driver);
            Assertions.assertTrue(axeResult.violationFree(), buildCustomReport(axeResult));
            // Process the results or perform assertions here

            // Recursively check iframes inside this iframe
            checkAccessibilityRecursive(driver);

            driver.switchTo().parentFrame(); // Switch back to the parent iframe
        }
    }
    public void excludeRulesAccessibilityWithCustomReport(List<String> excludedRules) {

        // Analyze the page creating a new AxeBuilder
        Results axeResult = new AxeBuilder().disableRules(excludedRules).analyze(driver);
        // Assert the page has no violations and if it has add the custom report
        Assertions.assertTrue(axeResult.violationFree(), buildCustomReport(axeResult));
    }

    public void excludingElementsAccessibilityWithCustomReport(List<String> excludedElements) {

        // Analyze the page creating a new AxeBuilder
        Results axeResult = new AxeBuilder().exclude(excludedElements).analyze(driver);
        // Assert the page has no violations and if it has add the custom report
        Assertions.assertTrue(axeResult.violationFree(), buildCustomReport(axeResult));
    }

    public void excludingSpecificElement(String excludedElement) {

        // Analyze the page creating a new AxeBuilder
        Results axeResult = new AxeBuilder().exclude(excludedElement).analyze(driver);
        // Assert the page has no violations and if it has add the custom report
        Assertions.assertTrue(axeResult.violationFree(), buildCustomReport(axeResult));
    }

    public static String buildCustomReport(final Results axeResult) {
        int ruleCounter = 1;
        int nodeCounter = 1;
        StringBuilder reportBuilder = new StringBuilder();
        for (Rule rule : axeResult.getViolations()) {
            reportBuilder.append("_________________________________________________________________________________\n")
                    .append(ruleCounter).append(") ").append(rule.getDescription()).append(".").append("\n")
                    .append(rule.getHelpUrl()).append("\n");
            for (CheckedNode checkedNode : rule.getNodes()) {
                reportBuilder.append(ruleCounter).append(".").append(nodeCounter).append(") ")
                        .append(checkedNode.getTarget()).append("\n")
                        .append(checkedNode.getFailureSummary()).append("\n\n");
                nodeCounter++;
            }
            ruleCounter++;
            nodeCounter = 1;
        }
        return reportBuilder.toString();
    }

}







