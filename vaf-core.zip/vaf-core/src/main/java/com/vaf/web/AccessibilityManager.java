//package com.vaf.web;
//
//import com.deque.axe.AXE;
//import com.paulhammant.ngwebdriver.NgWebDriver;
//import com.vaf.enumerations.BrowserType;
//import com.vaf.utils.ConfigUtil;
//import org.json.JSONArray;
//import org.json.JSONObject;
//import org.openqa.selenium.*;
//import org.testng.Assert;
//
//import java.net.URL;
//
//
//public class AccessibilityManager {
//
//
//
//	public WebDriver driver;
//	Browser browser = new Browser();
//	private NgWebDriver ngWebDriver = null;
//
//	public static String currentBrowser = "";
//
//	private static  final URL scripturl=UIManager.class.getResource("/axe.min.js");
//	public AccessibilityManager() {
//		AccessibilityManager.currentBrowser = ConfigUtil.CONFIG_GET_STRING("Browser").toUpperCase();
//
//		String browserType = ConfigUtil.CONFIG_GET_STRING("Browser").toUpperCase();
//		boolean headless = Boolean.parseBoolean(ConfigUtil.CONFIG_GET_STRING("headless"));
//		this.driver = browser.getInstance(BrowserType.valueOf(browserType), headless);
//
//	}
//
//	public AccessibilityManager(BrowserType browserType, boolean headless) {
//		String webBrowser = browserType.toString();
//		this.driver = browser.getInstance(BrowserType.valueOf(webBrowser), headless);
//	}
//
//	// Session Methods
//	public void startSession(String url) {
//
//		driver.get(url);
//
//	}
//
//
//	public void endSession() {
//		driver.quit();
//	}
//
//
//	public void accesibility() {
//		JSONObject jsonresponse=new AXE.Builder(driver,scripturl).analyze();
//		JSONArray violations=jsonresponse.getJSONArray("violations");
//
//		if(violations.length()==0){
//			System.out.println("No error");
//		} else{
//			AXE.writeResults("accesibility",jsonresponse);
//			Assert.assertTrue(false,AXE.report(violations));
//		}
//	}
//
//	public void accessibilitys() {
//		JSONObject jsonresponse = new AXE.Builder(driver, scripturl).analyze();
//		JSONArray violations = jsonresponse.getJSONArray("violations");
//
//		if (violations.length() == 0) {
//			System.out.println("No accessibility issues found.");
//		} else {
//			int crucialCount = 0;
//			int seriousCount = 0;
//			int moderateCount = 0;
//			int minorCount = 0;
//
//			AXE.writeResults("accessibility", jsonresponse);
//
//			System.out.println("Accessibility Issues:\n");
//
//			for (int i = 0; i < violations.length(); i++) {
//				JSONObject violation = violations.getJSONObject(i);
//				String impact = violation.getString("impact");
//				String description = violation.getString("description");
//				JSONArray nodes = violation.getJSONArray("nodes");
//
//				System.out.println("Issue " + (i + 1) + ": " + description + " [Impact: " + impact + "]");
//				System.out.println("  Details: " + violation.getString("help"));
//
//				// Print each affected element
//				System.out.println("  Elements Affected:");
//				for (int j = 0; j < nodes.length(); j++) {
//					JSONObject node = nodes.getJSONObject(j);
//					System.out.println("    " + node.getString("html"));
//				}
//
//				// Print fix suggestions if available
//				if (violation.has("helpUrl")) {
//					System.out.println("  Fix any of the following:");
//					System.out.println("    " + violation.getString("helpUrl"));
//				}
//
//				if (impact.equalsIgnoreCase("critical")) {
//					crucialCount++;
//				} else if (impact.equalsIgnoreCase("serious")) {
//					seriousCount++;
//				} else if (impact.equalsIgnoreCase("moderate")) {
//					moderateCount++;
//				} else if (impact.equalsIgnoreCase("minor")) {
//					minorCount++;
//				}
//
//				System.out.println(); // Adding an empty line between issues for better readability
//			}
//
//			// Print the Accessibility Issue Summary
//			System.out.println("Accessibility Issue Summary:");
//			System.out.println("Critical issues: " + crucialCount);
//			System.out.println("Serious issues: " + seriousCount);
//			System.out.println("Moderate issues: " + moderateCount);
//			System.out.println("Minor issues: " + minorCount);
//		}
//	}
//
//
//}
