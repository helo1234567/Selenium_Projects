package com.vaf.utils;

import java.io.File;
import java.io.FileNotFoundException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.Scanner;

public class FileUtil {
    static FileUtil _shared;
    public static FileUtil shared(){
        if (_shared == null){
            _shared = new FileUtil();
        }
        return _shared;
    }
    /**
     * Load contents of the file data.
     *
     * @filePath dirPath absolute path to directory
     * @return String - Data read from the file, returned String is empty if read failed.
     * @throws URISyntaxException
     */
    public String readFile(String filePath) throws URISyntaxException {

        try {
            // get the file url, not working in JAR file.
            URL resource = getClass().getClassLoader().getResource(filePath);//.getResource("config.json");
            if (resource == null) {
                throw new IllegalArgumentException("file not found!");
            } else {
                // failed if files have whitespaces or special characters
                //return new File(resource.getFile());

                File myObj = new File(resource.toURI());
                //File myObj = new File(filePath);
                Scanner myReader = new Scanner(myObj);

                String data = "";

                while (myReader.hasNextLine()) {
                    data = data + myReader.nextLine();

                }

                myReader.close();

                return data;
            }



        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();

        }

        return "";
    }
}
