package com.vaf.utils;

public class ReportsDashboardutil {

    static String performancelinkFilePath = "src/test/resources/Reports/performancelink.html"; // Change this to your desired path
    static String uiapilinkFilePath = "src/test/resources/Reports/uiapilink.html";
    public static void generateDashboard(){
        generatePerformanceReport();
        generateUIAPIReport();
    }
    public static void generatePerformanceReport(){
        String gatling_links_string = FileUtil.readGatlingFolder();
        FileUtil.writeFile(performancelinkFilePath, htmlTop.replaceAll("PAGE_TITLE", "Performance Reports")+gatling_links_string+htmlBot);
    }

    public static void generateUIAPIReport(){
        String rp_url = "<a href='"+ ConfigUtil.CONFIG_GET_STRING("reportPortal_url") +"'>OPEN REPORT PORTAL</a>";
        FileUtil.writeFile(uiapilinkFilePath, htmlTop.replaceAll("PAGE_TITLE", "UI & API Reports")+rp_url+htmlBot);
    }

    static String htmlTop = "<!DOCTYPE html> <html lang='en'> <head>     <meta charset='UTF-8'>     <title>PAGE_TITLE</title>     <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.0/jquery.min.js'></script>     <!-- Latest compiled and minified CSS -->     <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css' integrity='sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u' crossorigin='anonymous'>     <link rel='stylesheet' href='content/site.css'>     <!-- Optional theme -->     <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap-theme.min.css' integrity='sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp' crossorigin='anonymous'>     <!-- Latest compiled and minified JavaScript -->     <script src='https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js' integrity='sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa' crossorigin='anonymous'></script>     <style>     </style> </head> <body> <div class='mainwrapper'>     <div class='logoandhead'>         <div class='logo'>             <img src='content/logo.png' height='40' width='160'/>         </div>         <div class='headingintro'>             <h2>PAGE_TITLE</h2>         </div>     </div> <div class='container'> <div class='links_container'>     <div class='link_div'>";
    static String htmlBot = "</div> </div> </div> </div> <footer>     <div class='logosmall'>         <img src='content/logo.png' height='20' width='80'/>         <label>Stellar is a comprehensive QA automation tool designed to streamline the software testing process. Stellar provides solutions for UI Automation testing, API Automation testing, performance testing, reporting, and more.</label>     </div>     <div class='footerlinks'>         <a href='https://vstellar.io/#/terms-condition' target='_blank'>Terms & Conditions</a>         <a href='https://vstellar.io/#/privacy-policy' target='_blank'>Privacy Policy</a>         <a href=''>Licensing</a>     </div>     <div class='footerrightdesc'>         © All rights reserved by <a href='https://www.vertexitsystems.com' target='_blank'>Vertex inc</a>.     </div> </footer> </body> </html>";
}
