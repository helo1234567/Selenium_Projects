package com.vaf.utils;
import com.vaf.api.APIManager;
import com.vaf.web.UIManager;
import io.qameta.allure.Attachment;
import org.testng.Assert;


public class Assertions {
    private static String DEFAULT_MESSAGE = "";

    public static void handleLogging(String message, UIManager manager, Runnable assertionBlock) throws AssertionError {
        try {
            assertionBlock.run();
        } catch (AssertionError error) {

            if (ConfigUtil.CONFIG_GET_STRING("EnableVerboseReporting").equals("true")) {
                    if (manager != null) {
                    manager.logScreenshot(message);
                    } else {
                    UIManager.logInfo(message);
                }
            }
            throw new AssertionError();
        }
    }


    public static void assertEquals(boolean original, boolean expected, String message) {
        assertEquals(original, expected, message, null);
    }
    public static void assertEquals(String original, String expected, String message, UIManager manager) {
        handleLogging(message, manager, () -> {
            Assert.assertEquals(original, expected, message);
        });
    }
    public static void assertEquals(String original, String expected,String message) {
        assertEquals(original, expected,message,null);
    }
    public static void assertEquals(int original, int expected, String message, UIManager manager) {
        handleLogging(message, manager, () -> {
            Assert.assertEquals(original, expected, message);
        });
    }
    public static void assertEquals(boolean original, boolean expected, String message,UIManager manager) {
        handleLogging(message, manager, () -> {
            Assert.assertEquals(original, expected, message);
        });
    }
    public static void assertEquals(int original, int expected, String message) {
        assertEquals(original,expected,message,null);
    }
    public static void assertEquals(double original, double expected, double delta, String message, UIManager manager) {
        handleLogging(message, manager, () -> {
            Assert.assertEquals(original, expected, delta, message);
        });
    }
    public static void assertEquals(double original, double expected, double delta, String message) {
        assertEquals(original,expected,delta,message,null);
    }
    public static void assertEquals(Object original, Object expected, String message, UIManager manager) {
        handleLogging(message, manager, () -> {
            Assert.assertEquals(original, expected, message);
        });
    }
    public static void assertEquals(Object original,Object expected,String message) {
            assertEquals(original, expected,message,null);
    }
    public static void assertTrue(boolean condition, String message)  {
        assertTrue(condition, message, null);
    }
    public static void assertTrue(boolean condition, String message, UIManager manager)  {
        handleLogging(message, manager, ()->{
            Assert.assertTrue(condition, message);
        });
    }
    public static void assertTrue(boolean condition){
        assertTrue(condition,Assertions.DEFAULT_MESSAGE,null);
    }
    public static void assertFalse(boolean condition, String message) {
        assertFalse(condition, message, null);
    }
    public static void assertFalse(boolean condition, String message, UIManager manager) {
        handleLogging(message, manager, ()->{
            Assert.assertFalse(condition, message);
        });
    }
    public static void assertFalse(boolean condition){
        assertFalse(condition,Assertions.DEFAULT_MESSAGE,null);
    }
    public static void assertNull(Object object){
        assertNull(object,Assertions.DEFAULT_MESSAGE,null);
    }
    public static void assertNull(Object object, String message) {
        assertNull(object,message,null);
    }
    public static void assertNull(Object object, String message, UIManager manager) {
        handleLogging(message, manager, () -> {
            Assert.assertNull(object, message);
        });
    }
    public static void assertNotNull(Object object){
        assertNotNull(object,Assertions.DEFAULT_MESSAGE,null);
    }
    public static void assertNotNull(Object object, String message) {
        assertNotNull(object,message,null);
    }
    public static void assertNotNull(Object object, String message, UIManager manager) {
        handleLogging(message, manager, () -> {
            Assert.assertNotNull(object, message);
        });
    }
    public static void assertSame(Object original,Object expected,String message) {
        assertSame(original,expected,message,null);
    }
    public static void assertSame(Object original,Object expected,String message,UIManager manager) {
        handleLogging(message, manager, () -> {
            Assert.assertSame(original, expected, message);
        });
    }
    public static void assertNotSame(Object original,Object unexpected,String message) {
        assertNotSame(original,unexpected,message,null);
    }
    public static void assertNotSame(Object original,Object unexpected,String message,UIManager manager) {
        handleLogging(message, manager, () -> {
            Assert.assertNotSame(original, unexpected, message);
        });
    }
    public static void fail(){
        Assert.fail(Assertions.DEFAULT_MESSAGE,null);
    }
    public static void fail(String message) {
        fail(message, null);
    }
    public static void fail(String message,UIManager manager) {
        handleLogging(message, manager, () -> {
            Assert.fail(message);
        });
    }


}
