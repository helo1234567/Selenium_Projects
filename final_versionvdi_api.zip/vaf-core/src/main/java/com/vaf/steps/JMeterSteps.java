package com.vaf.steps;

import com.vaf.utils.ConfigUtil;
import com.vaf.utils.ExcelUtil;
import cucumber.api.java.en.When;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.apache.jmeter.assertions.ResponseAssertion;
import org.apache.jmeter.assertions.gui.AssertionGui;
import org.apache.jmeter.config.Arguments;
import org.apache.jmeter.config.gui.ArgumentsPanel;
import org.apache.jmeter.control.LoopController;
import org.apache.jmeter.control.gui.LoopControlPanel;
import org.apache.jmeter.control.gui.TestPlanGui;
import org.apache.jmeter.engine.StandardJMeterEngine;
import org.apache.jmeter.extractor.json.jsonpath.JSONPostProcessor;
import org.apache.jmeter.extractor.json.jsonpath.gui.JSONPostProcessorGui;
import org.apache.jmeter.protocol.http.control.Header;
import org.apache.jmeter.protocol.http.control.HeaderManager;
import org.apache.jmeter.protocol.http.control.gui.HttpTestSampleGui;
import org.apache.jmeter.protocol.http.sampler.HTTPSampler;
import org.apache.jmeter.protocol.http.util.HTTPArgument;
import org.apache.jmeter.reporters.ResultCollector;
import org.apache.jmeter.reporters.Summariser;
import org.apache.jmeter.samplers.SampleSaveConfiguration;
import org.apache.jmeter.testelement.TestElement;
import org.apache.jmeter.testelement.TestPlan;
import org.apache.jmeter.threads.ThreadGroup;
import org.apache.jmeter.threads.gui.ThreadGroupGui;
import org.apache.jmeter.util.JMeterUtils;
import org.apache.jorphan.collections.HashTree;
import org.json.JSONObject;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import static com.vaf.utils.LogUtil.logInfo;


public class JMeterSteps {
    ExcelUtil mg=new ExcelUtil();

    @When("user send {string} request for key {string} at endpoint {string} with <{int}> users during <{int}> seconds for <{int}> time")
    public void Jmeter(String request,String key1,String endpoint,int users,int rampUP,int loop) throws IOException {


        ArrayList<String> data = (ArrayList<String>) mg.getData(key1);
        // Create the Jmeter engine
        StandardJMeterEngine jm = new StandardJMeterEngine();

        // Set some configuration
        String jmeterHome = "src/main/resources";
        JMeterUtils.setJMeterHome(jmeterHome);
        JMeterUtils.loadJMeterProperties(jmeterHome + "/jmeter.properties");
        JMeterUtils.initLocale();

        // Create a sampler
        String ep = ConfigUtil.GET_ENDPOINT(endpoint);
        String baseuri = ConfigUtil.BASEURI("performnce");
        HTTPSampler httpSamplerOne = new HTTPSampler();
        httpSamplerOne.setDomain(baseuri);
        httpSamplerOne.setPath(ep);
        httpSamplerOne.setMethod(request);
        httpSamplerOne.setName("HTTP Request One");
        httpSamplerOne.setProtocol("https");
        httpSamplerOne.setProperty(TestElement.TEST_CLASS, HTTPSampler.class.getName());
        httpSamplerOne.setProperty(TestElement.GUI_CLASS, HttpTestSampleGui.class.getName());

        JSONPostProcessor jsonExtractor = new JSONPostProcessor();
        jsonExtractor.setName("JSON Extractor");
        jsonExtractor.setRefNames("foo");
        jsonExtractor.setJsonPathExpressions("$.title");
        jsonExtractor.setProperty(TestElement.TEST_CLASS, JSONPostProcessor.class.getName());
        jsonExtractor.setProperty(TestElement.GUI_CLASS, JSONPostProcessorGui.class.getName());

        // Create a loop controller
        LoopController loopController = new LoopController();
        loopController.setLoops(loop);
        loopController.setFirst(true);
        loopController.setProperty(TestElement.TEST_CLASS, LoopController.class.getName());
        loopController.setProperty(TestElement.GUI_CLASS, LoopControlPanel.class.getName());
        loopController.initialize();

        // Create a thread group
        ThreadGroup threadGroup = new ThreadGroup();
        threadGroup.setName("First Thread Group");
        threadGroup.setNumThreads(users);
        threadGroup.setRampUp(rampUP);
        threadGroup.setSamplerController(loopController);
        threadGroup.setProperty(TestElement.TEST_CLASS, ThreadGroup.class.getName());
        threadGroup.setProperty(TestElement.GUI_CLASS, ThreadGroupGui.class.getName());


        //////////////////////////////////////query paaraams////////////////////////////

        HTTPArgument param1 = new HTTPArgument();
        //param1.setName("key");
        param1.setValue(data.get(3));
        param1.setAlwaysEncoded(true);
        param1.setUseEquals(true);
        httpSamplerOne.getArguments().addArgument(param1);

        /////////////////////////////////////body/////////////////////////////////////

        HTTPArgument bodyArg = new HTTPArgument();
        bodyArg.setValue(data.get(1));
        bodyArg.setAlwaysEncoded(false); // Set to true if you want the body to be URL-encoded
        httpSamplerOne.setPostBodyRaw(true); // Set the request body type to "raw"
        Arguments args = new Arguments();
        args.addArgument(bodyArg);
        httpSamplerOne.setArguments(args);

        ///////////////////////////////////Headers////////////////////////////////////////
        String headersJsonString = data.get(2);

        // Parse the JSON string to a JSONObject
        JSONObject headersJson = new JSONObject(headersJsonString);

        // Create a HeaderManager instance
        HeaderManager headerManager = new HeaderManager();
        headerManager.setName("HTTP Header Manager");

        // Iterate over the headers and add them to the HeaderManager
        for (String key : headersJson.keySet()) {
            String value = headersJson.getString(key);
            headerManager.add(new Header(key, value));
        }

        // Set the HeaderManager to the HTTPSampler
        httpSamplerOne.setHeaderManager(headerManager);

        ///////////////////////////////////////////Form parametrs//////////////////////////

        HTTPArgument userIdArg = new HTTPArgument();
        userIdArg.setName("");
        userIdArg.setValue("");

        httpSamplerOne.addTestElement(userIdArg);

        /////////////////////////////////////Assertion/////////////////////////////////////

        // Response Assertion
        ResponseAssertion ra = new ResponseAssertion();
        ra.setProperty(TestElement.GUI_CLASS, AssertionGui.class.getName());
        ra.setName(JMeterUtils.getResString("assertion_title"));
        ra.setTestFieldResponseCode();
        ra.setToEqualsType();
        ra.addTestString("404");

        // Create a test plan
        TestPlan testPlan = new TestPlan("Test Plan");
        testPlan.setProperty(TestElement.TEST_CLASS, TestPlan.class.getName());
        testPlan.setProperty(TestElement.GUI_CLASS, TestPlanGui.class.getName());
        testPlan.setUserDefinedVariables((Arguments) new ArgumentsPanel().createTestElement());

        // Create a new hash tree to hold our test elements
        HashTree testPlanTree = new HashTree();
        // Add the test plan to our hash tree, this is the top level of our test
        testPlanTree.add(testPlan);

        // Create another hash tree and add the thread group to our test plan
        HashTree threadGroupHashTree = testPlanTree.add(testPlan, threadGroup);

        // Create a hash tree to add the post processor to
        HashTree httpSamplerOneTree = new HashTree();
        httpSamplerOneTree.add(httpSamplerOne, jsonExtractor);
        httpSamplerOneTree.add(httpSamplerOne, ra);

        // Add the http sampler to the hash tree that contains the thread group
        threadGroupHashTree.add(httpSamplerOneTree);



        // Summariser
        Summariser summariser = null;
        String summariserName = JMeterUtils.getPropDefault("summarise.names", "summary response");
        if (summariserName.length() > 0) {
            summariser = new Summariser(summariserName);
        }

        ResultCollector logger = new ResultCollector(summariser);
        testPlanTree.add(testPlanTree.getArray()[0], logger);

        // Write to a file
        ResultCollector rc = new ResultCollector();
        rc.setEnabled(true);
        rc.setErrorLogging(false);
        rc.isSampleWanted(true);
        SampleSaveConfiguration ssc = new SampleSaveConfiguration();
        ssc.setTime(true);
        ssc.setAssertionResultsFailureMessage(true);
        ssc.setThreadCounts(true);
        rc.setSaveConfig(ssc);
        rc.setFilename("src/test/resources/Reports/FirstTest.jtl");
        //rc.setFilename("src/test/resources/Reports/FirstTest.csv");
        testPlanTree.add(testPlanTree.getArray()[0], rc);

        // Configure
        jm.configure(testPlanTree);

        // Run
        jm.run();


        try (CSVParser parser = new CSVParser(new FileReader("src/test/resources/Reports/FirstTest.jtl"), CSVFormat.DEFAULT)) {
            long minSampleTime = Long.MAX_VALUE;
            long maxSampleTime = Long.MIN_VALUE;
            long sumSampleTime = 0;
            int sampleCount = 0;

            boolean skipHeader = true; // Flag to skip the header row

            for (CSVRecord record : parser) {
                if (skipHeader) {
                    skipHeader = false;
                    continue; // Skip the header row
                }

                String sampleTimeStr = record.get(1); // Assuming sample time is in the second column
                long sampleTime = Long.parseLong(sampleTimeStr);
                logInfo("SampleTime: " + sampleTime + " milliseconds");

                minSampleTime = Math.min(minSampleTime, sampleTime);
                maxSampleTime = Math.max(maxSampleTime, sampleTime);
                sumSampleTime += sampleTime;
                sampleCount++;
            }

            if (sampleCount > 0) {
                long averageSampleTime = sumSampleTime / sampleCount;

                logInfo("Minimum Sample Time: " + minSampleTime + " milliseconds");
                logInfo("Maximum Sample Time: " + maxSampleTime + " milliseconds");
                logInfo("Average Sample Time: " + averageSampleTime + " milliseconds");
            } else {
                System.out.println("No samples found.");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
