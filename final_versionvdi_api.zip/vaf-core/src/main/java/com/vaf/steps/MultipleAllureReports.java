package com.vaf.steps;

import io.qameta.allure.Allure;
import io.qameta.allure.Description;
import io.qameta.allure.Step;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

public class MultipleAllureReports {





    @Test
    @Description("Test 1")
    public void test1() {
        System.setProperty("allure.results.directory", "allure-results");
        testStep("Test 1 passed.");
        testStep("Test 2 passed.");
        testStep("Test 3 passed.");
    }

    @Test
    @Description("Test 2")
    public void test2() {
        System.setProperty("allure.results.directory", "allure-results");
        testStep("Test 3 failed.");
        testStep("Test 4 failed.");
        testStep("Test 5 failed.");
    }

    @Step("{0}")
    public void testStep(String message) {
        System.out.println(message);
        Allure.step(message);
    }
}