package com.vaf.utils;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
//import com.aventstack.extentreports.reporter.configuration.ChartLocation;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class addGraphs {

        public static void main(String[] args) {
//            // Create the extent report and its components
//            ExtentSparkReporter reporter = new ExtentSparkReporter("path/to/report.html");
//            reporter.config().setChartVisibilityOnOpen(true);
//            reporter.config().setDocumentTitle("Extent Report Example");
//            reporter.config().setReportName("Extent Report Demo");
//            reporter.config().setTestViewChartLocation(ChartLocation.TOP);
//            reporter.config().setTheme(Theme.STANDARD);
//
//            ExtentReports extent = new ExtentReports();
//            extent.attachReporter(reporter);
//
//            ExtentTest test = extent.createTest("Test 1");
//
//            // Log test results and add multiple charts
//            test.pass("Test passed.");
//
//            // Add the first chart
//            test.createNode("Chart 1")
//                    .createChart(ChartType.PIE)
//                    .data(new int[]{40, 30, 20})
//                    .labels(new String[]{"Pass", "Fail", "Skip"})
//                    .build();
//
//            // Add the second chart
//            test.createNode("Chart 2")
//                    .createChart(ChartType.BAR)
//                    .data(new int[]{10, 20, 30})
//                    .labels(new String[]{"Category 1", "Category 2", "Category 3"})
//                    .build();
//
//            // Add other charts as needed
//
//            // Close the extent report to generate the report
//            extent.flush();



            /***************************/

            // Create the extent report and its components
            ExtentSparkReporter reporter = new ExtentSparkReporter("index.html");
            ExtentReports extent = new ExtentReports();
            extent.attachReporter(reporter);

            ExtentTest test = extent.createTest("Test 1");

            // Log test results and add multiple charts using custom HTML markup
            test.pass("Test passed.");

//            // Add chart 1
//            String chart1Markup = "<img src='src/main/resources/logo/graph1.png' alt='Chart 1'>";
//            test.info(chart1Markup);

//            // Add chart 2
//            String chart2Markup = "<img src='src/main/resources/logo/graph2.png' alt='Chart 2'>";
//            test.info(chart2Markup);

            // Add chart 3
            Integer total_tests = 100;
            Integer passed_tests = 45;

            String chart3Markup = "<div style='width:"+total_tests+"'><div style='width:"+passed_tests+"'></div></div>";//"<img src='src/main/resources/logo/graph3.png' alt='Chart 3'>";
            test.info(chart3Markup);

            // Add other charts as needed

            // Close the extent report to generate the report
            extent.flush();
        }
}
