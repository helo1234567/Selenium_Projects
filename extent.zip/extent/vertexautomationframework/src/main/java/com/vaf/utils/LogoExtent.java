package com.vaf.utils;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import java.awt.*;
import java.io.File;
import java.io.IOException;

public class LogoExtent {
    /*
    *   Attach Company Logo
    *   How to use config files to setup extent report (XML config file)
    *
    * */

    public static void main(String args[]) throws IOException {
        attachLogoTest();
    }

    public static void attachLogoTest() throws IOException {

        ExtentReports extent = new ExtentReports();
        ExtentSparkReporter spark = new ExtentSparkReporter("index.html");
        spark.loadXMLConfig(new File("src/main/resources/extentConfig.xml"));
        extent.attachReporter(spark);

        ExtentTest test = extent.createTest("First Test");
        test.pass("Test started");
        test.pass("test finished");

        extent.flush();
        Desktop.getDesktop().browse(new File("index.html").toURI( ));

    }


}
