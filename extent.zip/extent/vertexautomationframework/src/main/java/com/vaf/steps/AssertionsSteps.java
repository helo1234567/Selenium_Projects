package com.vaf.steps;

import com.vaf.utils.Assertions;
import com.vaf.utils.ExcelUtil;
import com.vaf.web.UIManager;
import cucumber.api.java.en.Then;
import io.restassured.path.json.JsonPath;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.Map;

public class AssertionsSteps {

    UIManager mgr = UISteps.mgr;

    @Test
    @Then("Verify that {string} should be selected already")
    public void verify_isSelected(String key) {
        Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key);
        String value = (String) locatorMap.get("value");
        UIManager.LocatorType type = (UIManager.LocatorType) locatorMap.get("type");
        WebElement we=mgr.elementBy(type,value);
        Assertions.assertTrue(we.isSelected(),"Verify expected Button is selected",mgr);

    }

    @Test
    @Then("Verify that user will see {string}")
    public void verify_nextpage_locator(String key) {
        Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key);
        String value = (String) locatorMap.get("value");
        UIManager.LocatorType type = (UIManager.LocatorType) locatorMap.get("type");
        WebElement we=mgr.elementBy(type,value);
        Assertions.assertTrue(we.isDisplayed(),"Verify expected value is visible",mgr);

    }

    @Test
    @Then("Verify that {string} is selected successfully from {string}")
    public void verify_dropdown_selection(String key1, String key2) {
        Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key1);
        Map<String, Object> locatorMap1 = ExcelUtil.getLocatorFor(key2);
        String value = (String) locatorMap.get("value");
        UIManager.LocatorType type = (UIManager.LocatorType) locatorMap.get("type");
        String value1 = (String) locatorMap1.get("value");
        UIManager.LocatorType type1 = (UIManager.LocatorType) locatorMap1.get("type");
        WebElement we=mgr.elementBy(type,value);
        Assertions.assertTrue(we.isDisplayed(),"Verify expected value is selected succesfully",mgr);

    }

    @Test
    @Then("Verify that user will see {string} on next page")
    public void Verify_Nextpage_ocator(String key) {
        Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key);
        String value = (String) locatorMap.get("value");
        UIManager.LocatorType type = (UIManager.LocatorType) locatorMap.get("type");
        WebElement we=mgr.elementBy(type,value);
        Assertions.assertTrue(we.isDisplayed(),"Verify expected value is visible",mgr);

    }

    @Test
    @Then("Verify that the {string} button should be enabled")
    public void Verify_Button_Enability(String key) {
        Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key);
        String value = (String) locatorMap.get("value");
        UIManager.LocatorType type = (UIManager.LocatorType) locatorMap.get("type");
        WebElement we=mgr.elementBy(type,value);
        Assertions.assertTrue(we.isEnabled(),"Verify expected Button should be enabled",mgr);

    }

    @Test
    @Then("Verify that the URL of page should be {string}")
    public void Verify_URL(String Current_URL) {
        String actual_URL = mgr.getURL();
        Assertions.assertEquals(actual_URL, Current_URL, "Verify that URL is matched or not",mgr);
    }

    @Test
    @Then("Verify that User will see {string} after Hover over")
    public void verify_dropdown_value(String key) throws IOException {
        Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key);
        String value = (String) locatorMap.get("value");
        UIManager.LocatorType type = (UIManager.LocatorType) locatorMap.get("type");
        WebElement we=mgr.elementBy(type,value);
        Assertions.assertTrue(we.isDisplayed(),"Verify expected value appears after Hover over",mgr);
    }

    @Test
    @Then("Verify that the title of page should be {string}")
    public void Verify_Title(String Page_Title) {
        String actual_Title = mgr.getTitle();
        Assertions.assertEquals(actual_Title, Page_Title, "Verify Title is matched or not",mgr);
    }

    @Test
    @Then("Verify that {string} should be disabled")
    public void verify_isDisabled(String key) {
        Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key);
        String value = (String) locatorMap.get("value");
        UIManager.LocatorType type = (UIManager.LocatorType) locatorMap.get("type");
        WebElement we = mgr.elementBy(type, value);
        Assertions.assertFalse(we.isEnabled(), "Verify expected Button is disabled", mgr);
    }

    @Test
    @Then("Verify that {string} text should be {string}")
    public void verify_text(String key, String expectedText) {
        Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key);
        String value = (String) locatorMap.get("value");
        UIManager.LocatorType type = (UIManager.LocatorType) locatorMap.get("type");
        WebElement we = mgr.elementBy(type, value);
        String actualText = we.getText();
        Assertions.assertEquals(actualText, expectedText, "Verify expected text is displayed", mgr);
    }

    @Test
    @Then("Verify that {string} attribute should be {string}")
    public void verify_attribute(String key, String expectedAttributeValue) {
        Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key);
        String value = (String) locatorMap.get("value");
        UIManager.LocatorType type = (UIManager.LocatorType) locatorMap.get("type");
        WebElement we = mgr.elementBy(type, value);
        String actualAttributeValue = we.getAttribute("attributeName");
        Assertions.assertEquals(actualAttributeValue, expectedAttributeValue, "Verify expected attribute value", mgr);
    }

    @Test
    @Then("Verify that {string} should contain {string}")
    public void verify_contains(String key, String expectedText) {
        Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key);
        String value = (String) locatorMap.get("value");
        UIManager.LocatorType type = (UIManager.LocatorType) locatorMap.get("type");
        WebElement we = mgr.elementBy(type, value);
        String actualText = we.getText();
        Assertions.assertTrue(actualText.contains(expectedText), "Verify expected text is contained", mgr);
    }

    @Test
    @Then("Verify that {string} should not contain {string}")
    public void verify_notContain(String key, String unexpectedText) {
        Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key);
        String value = (String) locatorMap.get("value");
        UIManager.LocatorType type = (UIManager.LocatorType) locatorMap.get("type");
        WebElement we = mgr.elementBy(type, value);
        String actualText = we.getText();
        Assertions.assertFalse(actualText.contains(unexpectedText), "Verify unexpected text is not contained", mgr);
    }

    @Test
    @Then("Verify that {string} should have attribute {string}")
    public void verify_hasAttribute(String key, String attributeName) {
        Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key);
        String value = (String) locatorMap.get("value");
        UIManager.LocatorType type = (UIManager.LocatorType) locatorMap.get("type");
        WebElement we = mgr.elementBy(type, value);
        Assertions.assertTrue(we.getAttribute(attributeName) != null, "Verify element has attribute", mgr);
    }

    @Test
    @Then("Verify that {string} should not have attribute {string}")
    public void verify_notHaveAttribute(String key, String attributeName) {
        Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key);
        String value = (String) locatorMap.get("value");
        UIManager.LocatorType type = (UIManager.LocatorType) locatorMap.get("type");
        WebElement we = mgr.elementBy(type, value);
        Assertions.assertTrue(we.getAttribute(attributeName) == null, "Verify element does not have attribute", mgr);
    }

    @Test
    @Then("Verify that {string} should have CSS class {string}")
    public void verify_hasCssClass(String key, String cssClass) {
        Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key);
        String value = (String) locatorMap.get("value");
        UIManager.LocatorType type = (UIManager.LocatorType) locatorMap.get("type");
        WebElement we = mgr.elementBy(type, value);
        String actualCssClasses = we.getAttribute("class");
        Assertions.assertTrue(actualCssClasses.contains(cssClass), "Verify element has CSS class", mgr);
    }

    @Test
    @Then("Verify that {string} should not have CSS class {string}")
    public void verify_notHaveCssClass(String key, String cssClass) {
        Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key);
        String value = (String) locatorMap.get("value");
        UIManager.LocatorType type = (UIManager.LocatorType) locatorMap.get("type");
        WebElement we = mgr.elementBy(type, value);
        String actualCssClasses = we.getAttribute("class");
        Assertions.assertFalse(actualCssClasses.contains(cssClass), "Verify element does not have CSS class", mgr);
    }

    @Then("verify that request was successful")
    public void validate_status_success() throws IOException {
        int actualStatusCode = ApiSteps.postresponse.statusCode();
        Assertions.assertEquals(200, actualStatusCode,"verify that status code is ok", null);
    }
    @Then("verify that status code should be <{int}>")
    public void validate_status_code(int status_code) throws IOException {
        int actualStatusCode = ApiSteps.postresponse.statusCode();
        Assertions.assertEquals(status_code, actualStatusCode,"verify that status code is ok", null);
    }

    @Then("verify that response had key {string}")
    public void validate_response_key(String key) throws IOException {
        JsonPath jsonPath = new JsonPath(ApiSteps.postresponse.asString());
        Assertions.assertTrue(jsonPath.get(key) != null, "verify that response has the key: " + key);
    }

    @Then("verify that response had key {string} with value {string}")
    public void validate_status_code(String key, String value) throws IOException {
        JsonPath jsonPath = new JsonPath(ApiSteps.postresponse.asString());
        String actualStatus = jsonPath.get(key);
        Assertions.assertEquals(value, actualStatus, "verify that response has the key "+key+" with the value "+value+"");
        }

    @Then("verify that response had key {string} with null value")
    public void validate_response_key_null_value(String key) throws IOException {
        JsonPath jsonPath = new JsonPath(ApiSteps.postresponse.asString());
        Object actualValue = jsonPath.get(key);
        Assertions.assertNull(actualValue, "verify that response has the key " + key + " with a null value");
    }

    @Then("verify that response had key {string} with value {int}")
    public void validate_response_key_integer_value(String key, int expectedValue) throws IOException {
        JsonPath jsonPath = new JsonPath(ApiSteps.postresponse.asString());
        int actualValue = jsonPath.get(key);
        Assertions.assertEquals(expectedValue, actualValue, "verify that response has the key " + key + " with the expected integer value: " + expectedValue);
    }

    @Then("verify that response had key {string} with value of type {string}")
    public void validate_response_key_value_type(String key, String expectedType) throws IOException {
        JsonPath jsonPath = new JsonPath(ApiSteps.postresponse.asString());
        Object actualValue = jsonPath.get(key);
        String actualType = actualValue.getClass().getSimpleName();
        Assertions.assertEquals(expectedType, actualType, "verify that response has the key: " + key + " with a value of type: " + expectedType);
    }
}
