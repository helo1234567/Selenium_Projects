package com.vaf.api;


import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.vaf.utils.ConfigUtil;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;
import org.hamcrest.Matchers;
import org.hamcrest.core.Is;
import org.json.JSONException;
import  org.json.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class APIManager {

    static String authURI     = "https://apis.spectrum.net";
    static String baseURI     = "https://api.spectrummobile.com";

    static String authEndpoint     = "/auth/oauth/v2";
    static String customerEndpoint = "/customer/api";
    static String buyFlowEndpoint  = "/buyflowsession/api";
    static String utilityEndpoint  = "/util/api";
    static String preAuthEndpoint  = "/selfservice/authn/v1";
    static String prodCatalogEndpoint = "/mbosproductcatalog/api";
    public static HashMap<String, String> jsonToMap(String t) throws JSONException {

        HashMap<String, String> map = new HashMap<String, String>();
        JSONObject jObject = new JSONObject(t);
        Iterator<?> keys = jObject.keys();

        while( keys.hasNext() ){
            String key = (String)keys.next();
            String value = jObject.getString(key);
            map.put(key, value);

        }

        return map;
    }

    public static boolean ValidJson(String jsonStr) {
        try {
            JsonElement jsonElement = JsonParser.parseString(jsonStr);
            return jsonElement.isJsonObject();
        } catch (Exception e) {
            return false;
        }
    }
    public static String autoFillResponseValues(String oldRequestBody, String newRequestBody)
    {
        HashMap<String, String> body = jsonToMap(oldRequestBody);
        Pattern pattern = Pattern.compile("#\\{(.*?)\\}", Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(newRequestBody);

        int index = 1;
        while (matcher.find()) {
            String keytoReplace = matcher.group(index);
            String valueToReplace = body.get(keytoReplace);

            newRequestBody=newRequestBody.replaceAll("#\\{"+keytoReplace+"\\}",""+valueToReplace);

        }
        return newRequestBody;
    }

    public Response PostRequest(String body, String header, String query, String endpoint, String method) {


        //RestAssured.baseURI = ConfigUtil.BASEURI("auth", ConfigUtil.ConfigType.APIConfig);
        String baseuri = ConfigUtil.BASEURI("auth");
        String ep = ConfigUtil.GET_ENDPOINT(endpoint);
        System.out.println("base: " + baseuri + ", endpoint: " + ep);
        Map<String, String> headers=jsonToMap(header);

        RequestSpecification request = RestAssured.given().baseUri(baseuri)
                .queryParam(query)
                .headers(headers)
                .body(body);

        Response response;



        if (method.equalsIgnoreCase("post")) {
            response = request.post(ep);
        } else if (method.equalsIgnoreCase("get")) {
            response = request.get(ep);
        }
        else if (method.equalsIgnoreCase("delete")) {
            response = request.delete(ep);
        }
        else if (method.equalsIgnoreCase("put")) {
            response = request.put(ep);
        }
        else {
            throw new IllegalArgumentException("Invalid request type: " + method);
        }

        return response;
    }

    public static RequestSpecification execute() {
        return RestAssured.given();
    }

    public static void verifyResponseOK(Response response) {
        ((ValidatableResponse)((ValidatableResponse)response.then()).assertThat()).statusCode(200);
    }

    public static void verifyHasKey(Response response, String key) {
        ((ValidatableResponse)response.then()).body("$", Matchers.hasKey(key), new Object[0]);
    }

    public static <T> void keyHasValue(Response response, String key, T value) {
        ((ValidatableResponse)response.then()).body(key, Is.is(value), new Object[0]);
    }





    public static Map<String, String> getBaseHeaderHash(){
        Map <String, String> headerHash = new HashMap<String, String>();
        headerHash.put("authority","apis.shared.uat-spectrum.net");
        headerHash.put("accept","application/json, text/plain, */*");
        headerHash.put("accept-language","en-US,en;q=0.9");
        headerHash.put("cache-control","no-cache");
        headerHash.put("content-type","application/x-www-form-urlencoded");
        headerHash.put("cookie","dla_device=5f3f9bff-a2ec-43bb-a519-5a7d5c6c13f3; dla_session=ZXlKbGEzTnBaQ0k2SW1Sc1lWOTBiMnRsYmw5emFHOXlkR3hwZG1Wa1gyVnVZM0o1Y0hSZmEyVjVjMlYwSWl3aVpXNWpJam9pUVRJMU5rTkNReTFJVXpVeE1pSXNJbUZzWnlJNklrRXlOVFpMVnlJc0ltcDBhU0k2SWpJME1UazVZV05sTFRSaVl6UXROREpsTkMwNVlURTBMVFV6TlRZNFlXTXpNemxoWXlJc0ltVnJhV1FpT2lJNE9EYzRORGcxWXkwMlpUZGxMVFE0WkRVdFlUZGtaUzFqWlRZME9XUmlNekUyTVRWZk1qQXlNQzB3TVMweU0xUXhOaTR4TlM0eE1pNHhNalZhSWl3aWMyVmpjRzlzSWpvaVpHeGhYM1J2YTJWdUxYTm9iM0owYkdsMlpXUWlmUS5MVW00c29jcWNOU0RkNDc3MFpzTFJuWE42dzduTFJ1OTI0NDE2T1VYbGtkWk13N2ZRc2l5ak5vM0NxTVJiZzAxTE5pZ2NMOEhSRnF2a2xkYm5oX1lfRVA5Y25QNFQ1Nm4uNFV0aDFRaTNfYkxIZTRhRVc5Vkc5QS5zcjRrM1dYdmpVQ3ZEZHcwV3AzbHl3T1N5SDlJaGRoRl9zbVJQRmRGclFDcjNEb05NZDgwaURpSjdQNFF2c3R1Q1ZwMTBSWk9rRjNwYW4tZlA2bXdFd3BzWWM0ZVF2cWRPaURtVEJ0S3hyVEFTVUdwQ0tpS1U5N2UxVkdNVXZDVHlwLTFITktyUFJuSnhkX0J3ZHk2eWZmMGNNRjF0cDUyeXVlLUlLTXdZS3pHNm13RlpKN1g1OWFyakpTMF9vSWlCazl0c0dNYW1rRDExT081YjBVanQyNTV3V2o1bkp6LUJudnJzSEp5VVVXR2FDSkwzTk9vZ09POGpSa3E4ZEFXWnhpM1ZtT1I2WTdpX3BDN28yamlXU2psRmsxRVNSbE1LTGN6SE5XZVZkUi1VVDBGRWdjUGlMdlJhRTk2SHRnMXhwVkxfTDlmNW5wUVFpTUVUeHAxOXM4Ulc0SFR3MW5kcTZrVHl5MWM1SlU2TWpHYnNYM05aRkdPNTNmNTJJTWp3SmJ6a3FEVkpocHl1a0FGblV6cl9XdkY0amdEd242MlNkeUdXd2ZnSVZkOFZzd0JoSHV1VkgwVjFvSjIteHVhakpsNXJ5ZlJtREpGTGRMeHdwRUd3WmtiQmY4Rzh4eE5LbXI1TGxKUFB1YU5tSmtvR3A5aF9vMUpBU0VTcm8zUWVFTVFHbmIteG9yWEp5aTJhalV6bnp5V0RLcE5YbWVzbG1RZVk3N0J2Z3UzVWdnd1NUdHRuQmV5ZURDS1R1TXl6WmJuZ3J0dDRsUUJ6bWlEX1JZbm5GdTJVWWhHWjFhQXJEVEFNVTZ0TDZVSHhmMmROaGhYejBhaXVLbzJ2ang1R3JOQVpPcW5CZWxUNS1oSnQ1RGF4cFFqVi1XU1E1S09BWGRaM1BxbXZKRUp4QW5jV1d4RTNsQm9xWHJoVzk0UUtObGRidTFzaFJ5dFR1UG41RGFVRzhGMGttOWViN2tldlBBRWUxdTd2ZndubDNhdWJtN3FmTlo3NVNad1B2MGFkYVBkczFxc0w4X3loQ3k5SHNEbjRqaU9aYm02cmkxT2dPbDBsbmFQVXhtVWo5dHdoTC1aN3lvamU5c1VCd2NxNkQwVFlsaTA5Zzh3UGdBaFlfZGN3MllLLWlSb084T25TeW1fNzNaMXltSkp4LWxHdmJrMFpzTDhVRklQWndXWHg2QlJ6ZS1XMFlnUmdJSEZFZHo3YmUyTl9wMmM4TVRkREpKSnlGc2xSelNBOGVud2FnSTdYbjZkSzkxZWV3RlhqNEJfd0xhcURYd2VuNWtpUDZLUk1wZjVQVkJhV3NDMElzcjF0T2I4bEJrOXZZbVM5Z19WVHhTbENTQ29DY3VOWl9kckZVSkY2cHRrYU9LaVFRemIwX3QzX1ZxV3BnQUJuazRSUDlzUW1YbV9oTkRLWUlIUVhCOFdwVm5PV1AxRWgwVnJ1ZmdyY0RleG5GVlpRYi1RQnBBQ2FMUXA5eHpMVnNqLVpKdllHVnhseUs4eHhDTGk5cHNReC1pWGZrZnNnQkJDX2J4MFluaHhEdFQ1V05JaTJIMVRsY3BHMmVXanZhbks3QU16bl9YM1JlcjVRTWt0V3ltSXg1SGI2RTRSdkVzT0g5LS1zaGtRSW05ZjBIYVc2OF8wSXp0b1p4UUtGWHFVam01ME0yY0xLQXVGR1QtZFB5eWdZMUxjaFVRb0N2M2k4OXNvN25iT2ZhOVVDV2hySlE3emZ1WGtBWDdtUUlZdXZDbTFDaG40cFJ1eGM2R3IyMjZEMFBVVG9NY0dKcXQyb2c0eHZPQmpvalZlemt5a29UUHFHYkk4REZ2MTlyZDNRUVB5SGcxalJSS3hNOFZndmd3em9iNnVSQVlnN1ZZMDVGVzJFREw5YXBSblZNd1hYbWZGVm5wR1VJcWZ4VWd0NHRCTk9oZldVT1R0Y29XaG1mRnBoRWJJenRla21JTDlPeEZSMlNyT2pfSFFiVEVtZFVWb1ZiQktZUnhhYXVHRlhZUmpCTndXZ2JFMFBSX0FJT1VlMDRFVmRsRU5lMDVia0J6cHVQN2RRMndIVFB2QVlaRlZZRVc1UXBZaHVuVEJaS0g2QVNBUTh0dFNtd19UVm5hdFYwWVJJbEZ1bWhyTGlSV0NiN0k3OTZmcjVsNDFYVF9BNEhYZ1Z1aFppaGhkeHhybXowMGpKSnJDUnZabGdrdWtaMENPaG54SmpnZTVfQ2RYOHkyZ0dMdThEeHJwdlZ3V1ZLMUlMQ0FYM1JNZVMwanVwQmdMTS1wQ2w4ejEwaGxibXVVa1J5a2NnUUs0SDFWczF3RnBQZGxSLWZINHpXYkpYTkpMalRXLVFsTEtzblJGSEZ2ZEpGUFFQUWZwNDlmV1pHT1I2YURVbGtXNzFfb1h4VW1FNFRnY0k1bVprX1dwNS1nQVhlaHdhTWNYUGE3NzNlenJZeEZTNXF4LXphSGJVRzBPNzQwb2R6cm0wTU50bDNqTjVOQmNPMEFTU0lvN1A4VzUzanpNY0hsWXFmNUZzWGJya09xWDN6QjJmeWNDV3RqX1VGYjByM0RVc3FtVjZwSldkQlpGaVN4Z2dSUjVIRUFnbkF0V09fdy1BQjNIZmFOcmlEVTUxbnRhUFhoejVSR25HLXJVd3NHMFN4YnlaZU5zdmN6eXo4NWZzelBHOXdtUnRFeFVDdURsTEQ2dTlZZlJhMENOZXN3SS16SDBuZWVwRFVZN3pOXzVNb3JKNDNZb2haM29FeTRKN1lzR0xDd25rb0hKMjB5dlBtQm1kaTQuWHZteWY0bjBGTWVhYTlVdzdLdkg0eUZpeXQydHd2YnlmdVFSTXQtNVo4RQ==; _cs_c=1; dla_marker=24199ace-4bc4-42e4-9a14-53568ac339ac; XSRF-TOKEN=e5459fcf8460e727d313876aba65275d; _cs_id=95295ec7-90f1-a411-b728-e0adeef9ab99.1666981578.6.1667068520.1667068520.1.1701145578338; _cs_s=1.5.0.1667070321048");
        headerHash.put("origin","https://id.portals.uat-spectrum.net");
        headerHash.put("pragma","no-cache");
        headerHash.put("referer","https://id.portals.uat-spectrum.net/");
        headerHash.put("sec-ch-ua","\"Chromium\";v=\"106\", \"Microsoft Edge\";v=\"106\", \"Not;A=Brand\";v=\"99\"");
        headerHash.put("sec-ch-ua-mobile","?0");
        headerHash.put("sec-ch-ua-platform","Windows");
        headerHash.put("sec-fetch-dest","empty");
        headerHash.put("sec-fetch-mode","cors");
        headerHash.put("sec-fetch-site","same-site");
        headerHash.put("user-agent","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36 Edg/106.0.1370.52");

        return headerHash;
    }

    public static Map<String, String> getMobileAuthHeaderHash(String akana_access_token){
        Map <String, String> headerHash = getBaseHeaderHash();

        headerHash.put("Authorization", ("Bearer " + akana_access_token) );

        return headerHash;
    }

    public static Map<String, String> getMobileHeaderHash(String akana_access_token, String mbo_access_token){
        Map <String, String> headerHash = getMobileAuthHeaderHash(akana_access_token);

        headerHash.put("sessionToken", mbo_access_token);

        return headerHash;
    }

    public static Response specAuthRequest() {

        Map<String, String> headerHash = getBaseHeaderHash();
        headerHash.put("authorization","Basic dGFtYWVna3lAY2hhcnRlci5uZXQ6VlBFNDI2d3FodTM1Sms=");
        headerHash.put("x-idm-client-origin","https://hotfix-buyflow.chartercom.com");
        headerHash.put("x-quantumvisitid","202210291448P-d5ca3350-40c1-4442-8ff4-179f721f1f4c");
        headerHash.put("x-rqc-mdc_txnid","202210291448P-d5ca3350-40c1-4442-8ff4-179f721f1f4c");
        headerHash.put("x-xsrf-token","e5459fcf8460e727d313876aba65275d");
        headerHash.put("xc-portal-source-client","IDM@1.46.0");

        Map <String, String> bodyHash = new HashMap<String, String>();
        bodyHash.put("client_id","mobile2_aem");
        bodyHash.put("response_type","code");
        bodyHash.put("nonce","777184443777554826493340752704");
        bodyHash.put("state","eyJ0YXJnZXRVcmwiOiIiLCJ4c3JmIjoiVDNZMmFrUXRWbUZsYUdrMFNFTm9TbWhEWTFaeFIwRTVhbEZJV1dSbVJreHJPSG8wVGs0MGVXUllNdyIsImFwcERhdGEiOnsic2t1Q29kZSI6Ijg4NzI3NjY2MjY1NyIsInNsdWciOiJnYWxheHktei1mbGlwNC1zYW1zdW5nIiwicHJvdGVjdGlvblBsYW4iOmZhbHNlLCJwYXltZW50VHlwZSI6IlBNIn19");
        bodyHash.put("code_challenge","rWFT4bVWGc0HNz2yxAx_YGhoxTPnw_2LyzXP_k2E7vE");
        bodyHash.put("code_challenge_method","S256");
        bodyHash.put("tmsid","qkla2legw41667068509202");
        bodyHash.put("redirect_uri","https://spectrum.com/mobile/login");
        bodyHash.put("clientSwitchRedirectUri","https://buy-uat2.spectrummobile.com/login");


        String username = "tamaegky@charter.net";
        String password = "VPE426wqhu35Jk";

        String path = authURI + authEndpoint + "/consumer/ca/password/auth";

        return APIManager.execute()
                .headers(headerHash)
                .formParams(bodyHash)
                .when()
                .post(path);
    }

    public static Response specTokenRequest(String authCode) {
        Map<String, String> headerHash = getBaseHeaderHash();

        Map <String, String> bodyHash = new HashMap<String, String>();
        bodyHash.put("client_id","mobile2_aem");
        bodyHash.put("grant_type","authorization_code");
        bodyHash.put("code",authCode);
        bodyHash.put("code_verifier","T3Y2akQtVmFlaGk0SENoSmhDY1ZxR0E5alFIWWRmRkxrOHo0Tk40eWRYMw");

        String path = authURI + authEndpoint + "/token";

        return APIManager.execute()
                .headers(headerHash)
                .formParams(bodyHash)
                .when()
                .post(path);
    }

    public static Response specLoginRequest(String akana_access_token, String mob_access_token) {
        Map<String, String> headerHash = getMobileHeaderHash(akana_access_token, mob_access_token);

        String path = baseURI + customerEndpoint + "/customer/account?preOrder=true";

        return APIManager.execute()
                .headers(headerHash)
                .when()
                .get(path);
    }

    public static Response specBuyInfoEligibilityRequest(String akana_access_token, String mob_access_token) {
        Map<String, String> headerHash = getMobileHeaderHash(akana_access_token, mob_access_token);


        String path = baseURI + buyFlowEndpoint + "/account/buyinfo?runEligibility=true";

        return APIManager.execute()
                .headers(headerHash)
                .when()
                .get(path);

    }

    public static Response specPublicKeyRequest(String akana_access_token) {
        Map<String, String> headerHash = getMobileAuthHeaderHash(akana_access_token);


        String path = baseURI + utilityEndpoint + "/publickey";

        return APIManager.execute()
                .headers(headerHash)
                .when()
                .get(path);

    }

    public static Response specMobileHomeRequest() {
        String path = baseURI + prodCatalogEndpoint + "/products?channel=ONLINE";

        return APIManager.execute()
                .when()
                .get(path);

    }

    public static Response specPlpPhonesRequest() {
        String path = baseURI + prodCatalogEndpoint+ "/products?category=DEVICE&channel=ONLINE";

        return APIManager.execute()
                .when()
                .get(path);

    }

    public static Response specPlpTabletRequest() {
        String path = baseURI + prodCatalogEndpoint + "/products?category=TABLET&channel=ONLINE";

        return APIManager.execute()
                .when()
                .get(path);

    }

    public static Response specPlpSmartwatchRequest() {
        String path = baseURI + prodCatalogEndpoint + "/products?category=SMART_WATCH&channel=ONLINE";

        return APIManager.execute()
                .when()
                .get(path);

    }

    public static Response specPdpPhonesDetSlugRequest() {
        String path = baseURI + prodCatalogEndpoint + "/product/details?slug=galaxy-z-flip4-samsung&channel=ONLINE";

        return APIManager.execute()
                .when()
                .get(path);

    }

    public static Response specPdpPhonesCompSlugRequest() {
        String path = baseURI + prodCatalogEndpoint + "/product/compatible?slug=galaxy-z-flip4-samsung";

        return APIManager.execute()
                .when()
                .get(path);

    }

    public static Response specPdpPhonesDetCatogRequest() {
        String path = baseURI + prodCatalogEndpoint + "/plans/details?categories=DEVICE&category=DEVICE&isByod=false&deviceSku=887276662657";

        return APIManager.execute()
                .when()
                .get(path);

    }

    public static Response specPdpTabletsDetSlugRequest(String slug) {
        String path = baseURI + prodCatalogEndpoint + "/product/details";

        return APIManager.execute()
                .queryParam("slug", slug).queryParam("channel", "ONLINE")
                .when()
                .get(path);

    }

    public static Response specPdpTabletsCompSlugRequest() {
        String path = baseURI + prodCatalogEndpoint + "/product/compatible?slug=ipad-apple";

        return APIManager.execute()
                .when()
                .get(path);

    }

    public static Response specPdpTabletsDetCatogRequest() {
        String path = baseURI + prodCatalogEndpoint + "/plans/details?categories=TABLET&category=TABLET&isByod=false&deviceSku=194253361336";

        return APIManager.execute()
                //.headers(headerHash)
                .when()
                .get(path);

    }

    public static Response specPdpSmartwatchDetSlugRequest() {
        String path = baseURI + prodCatalogEndpoint + "/product/details?slug=watch-se-40mm-apple&channel=ONLINE";

        return APIManager.execute()
                .when()
                .get(path);

    }

    public static Response specPdpSmartwatchCompSlugRequest() {
        String path = baseURI + prodCatalogEndpoint + "/product/compatible?slug=watch-se-40mm-apple";

        return APIManager.execute()
                .when()
                .get(path);

    }

    public static Response specPdpSmartwatchDetCatogRequest() {
        String path = baseURI + prodCatalogEndpoint + "/plans/details?categories=SMART_WATCH&category=SMART_WATCH&isByod=false&deviceSku=194253209546";

        return APIManager.execute()
                .when()
                .get(path);

    }

    public static Response specPreAuthRequest() {
        String path = authURI + preAuthEndpoint + "/authenticate";

        return APIManager.execute()
                .when()
                .get(path);

    }

}
