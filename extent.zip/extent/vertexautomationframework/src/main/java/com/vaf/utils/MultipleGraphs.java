package com.vaf.utils;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.markuputils.Markup;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class MultipleGraphs {
    public static void main(String[] args) {
        // Create the extent report and its components
        ExtentSparkReporter reporter = new ExtentSparkReporter("Reports/testGraph.html");
        ExtentReports extent = new ExtentReports();
        extent.attachReporter(reporter);

//        reporter.config().disableChartDisplay();

        ExtentTest test = extent.createTest("Test 1");

        // Log test results and add multiple graphs using custom HTML markup
        test.pass("Test passed.");

        // Add custom HTML markup with multiple graphs
        String htmlMarkup = "<h1>HELLO WORLD</h1>";
        test.info(htmlMarkup);

        // Add other test steps and graphs as needed

        // Close the extent report to generate the report
        extent.flush();
    }
}
