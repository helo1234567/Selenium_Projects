package com.vaf.utils;
import org.testng.ITestResult;
import org.testng.TestListenerAdapter;
import org.testng.TestNG;

public class TestCountExample {
    public static void main(String[] args) {
        // Create an instance of TestNG
        TestNG testng = new TestNG();

        // Create a TestListenerAdapter to listen to the test execution events
        TestListenerAdapter listener = new TestListenerAdapter();
        testng.addListener(listener);

        // Add your test classes or test suites to TestNG
        testng.setTestClasses(new Class[] { UISteps.class });

        // Run the tests
        testng.run();

        // Get the total test count from the TestListenerAdapter
        int totalTests = listener.getPassedTests().size() +
                listener.getFailedTests().size() +
                listener.getSkippedTests().size();

        // Print the total test count
        System.out.println("Total tests executed: " + totalTests);
    }
}

// Your test class
class UISteps {
    // Test methods and configurations
}