package com.vaf.utils;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

import java.awt.*;
import java.io.File;
import java.io.IOException;
//import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class ExtentReport {
    public static void main(String args[]) throws IOException {
        extentTest();
    }
    public static void extentTest() throws IOException{
        ExtentReports extent = new ExtentReports();
        ExtentSparkReporter spark = new ExtentSparkReporter("index.html");
        spark.config().setTheme(Theme.DARK);
        spark.config().setReportName("Extent Reports Demo");
        extent.attachReporter(spark);

      // spark.config().setJs("document.getElementsByClassName('col-sm-12 col-md-4')[0].style.setProperty('min-inline-size','-webkit-fill-available');");

        // Set custom CSS for the report to adjust spacing
       // spark.config().setCss("body { padding: 50px; margin: 50px; }");
        spark.config().setCss(".extent-charts { display: none; }");


        ExtentTest test = extent.createTest("Login Test").assignAuthor("Abdul Shakoor").assignCategory("Smoke").assignCategory("Regression").assignDevice("chrome 84");
        test.pass("Login Test started successfully");
        test.info("URL is Loaded");
        test.info("Values entered");
        test.pass("Login Test completed successfully");

        ExtentTest test1 = extent.createTest("HomePage Test").assignAuthor("Umer").assignCategory("Regression").assignDevice("Firefox 60");
        test1.pass("HomePage Test started successfully");
        test1.info("URL is Loaded");
        test1.info("Values entered");
        test1.fail("HomePage Test failed miserably");

        extent.flush();
        Desktop.getDesktop().browse(new File("index.html").toURI());


    }
}
