package com.vaf.utils;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
//import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.markuputils.Markup;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class MultipleExtent {

    public static void main(String[] args) {
        // Create the first extent report and its components
        ExtentSparkReporter reporter1 = new ExtentSparkReporter("Reports/report1.html");
        ExtentReports extent1 = new ExtentReports();
        extent1.attachReporter(reporter1);

        ExtentTest test1 = extent1.createTest("Test 1");

        // Perform test actions and log results in the first report
        test1.pass("Test 1 passed.");
        test1.pass("Test 2 passed.");
        test1.pass("Test 3 passed.");

//         Disable Chart Option
        reporter1.config().setCss(".extent-charts { display: none; }");


        // Add custom HTML markup with multiple graphs
      //  String htmlMarkup = "<div><h3>Graph 1</h3><img src='path/to/graph1.png' alt='Graph 1'><h3>Graph 2</h3><img src='path/to/graph2.png' alt='Graph 2'></div>";
        String htmlMarkup = "cf5bb23f-6925-4c75-8b01-c370749e1286";
        test1.info(htmlMarkup);

        // Create the second extent report and its components
        ExtentSparkReporter reporter2 = new ExtentSparkReporter("Reports/report2.html");
        ExtentReports extent2 = new ExtentReports();
        extent2.attachReporter(reporter2);

        reporter2.config().setJs("document.getElementsByClassName('dashboard-view')[0].innerHTML += '<h3>This is the text which has been inserted by JS</h3>';");//dashboard-view

        //reporter2.config().setCSS(".chart-container { display: none; }");
        // Disable Chart Option

//        reporter2.config().setCss(".extent-charts { display: none; }");

        // Attach the spark reporter to the extent report instance
        extent2.attachReporter(reporter2);
        // Add chart 3
        Integer total_tests = 100;
        Integer passed_tests = 45;

        String chart3Markup = "<div class='abcxyz' style='width:"+total_tests+"'><div style='width:"+passed_tests+"'></div></div>";//"<img src='src/main/resources/logo/graph3.png' alt='Chart 3'>";
//        reporter1.getReport(chart3Markup);
// Create a Markup object with the custom HTML content
        Markup markup = MarkupHelper.createCodeBlock(chart3Markup);

        ExtentTest test2 = extent2.createTest("Test 2");

        // Create a Markup object with the custom HTML content
        Markup htmlMarkup1 = new Markup() {
            @Override
            public String getMarkup() {
                return chart3Markup;
            }
        };
        // Perform test actions and log results in the second report
        test2.fail("Test 3 failed.");
        test2.fail("Test 4 failed.");
        test2.fail("Test 5 failed.");

        // Close the extent reports to generate the reports
        extent1.flush();
        // extent1.close();

        extent2.flush();
        // extent2.close();

    }
}
