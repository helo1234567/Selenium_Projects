package com.vaf.steps;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

public class AllureReportGenerator {

    public static void main(String[] args) throws IOException {
        String resultDir = "allure-results";
        String gatlingReportDir = "allure-report-gatling";
        String jmeterReportDir = "allure-report-jmeter";

        // Create separate directories for Gatling and JMeter reports
        createDirectoryIfNotExists(gatlingReportDir);
        createDirectoryIfNotExists(jmeterReportDir);

        // Get all the result files from the result directory
        File[] resultFiles = new File(resultDir).listFiles((dir, name) -> name.endsWith(".json"));

        if (resultFiles != null) {
            for (File file : resultFiles) {
                // Read the JSON content from the result file
                String fileContent = new String(Files.readAllBytes(file.toPath()));

                // Check if the tag exists in the JSON content
                if (fileContent.contains("\"name\":\"tag\",\"value\":\"Gatling\"")) {
                    // Move the file to the Gatling report directory
                    Files.move(file.toPath(), Path.of(gatlingReportDir, file.getName()), StandardCopyOption.REPLACE_EXISTING);
                } else if (fileContent.contains("\"name\":\"tag\",\"value\":\"JMeter\"")) {
                    // Move the file to the JMeter report directory
                    Files.move(file.toPath(), Path.of(jmeterReportDir, file.getName()), StandardCopyOption.REPLACE_EXISTING);
                }
            }
        }
    }

    private static void createDirectoryIfNotExists(String directory) {
        File dir = new File(directory);
        if (!dir.exists()) {
            dir.mkdirs();
        }
    }
}
