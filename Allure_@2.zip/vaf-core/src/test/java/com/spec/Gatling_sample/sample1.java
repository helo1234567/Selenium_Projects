package com.spec.Gatling_sample;

import com.vaf.steps.PerformanceSteps;
import com.vaf.utils.ConfigUtil;
import com.vaf.utils.ExcelUtil;
import io.gatling.javaapi.core.ChainBuilder;
import io.gatling.javaapi.core.ScenarioBuilder;
import io.gatling.javaapi.core.Simulation;
import io.gatling.javaapi.http.HttpProtocolBuilder;
import io.gatling.javaapi.http.HttpRequestActionBuilder;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

import static com.vaf.api.APIManager.jsonToMap;
import static io.gatling.javaapi.core.CoreDsl.*;
import static io.gatling.javaapi.http.HttpDsl.http;
import static io.gatling.javaapi.http.HttpDsl.status;

public class sample1 extends Simulation {

    String request = PerformanceSteps.Request;
    int user = PerformanceSteps.Users;
    int rampUP = PerformanceSteps.RampUP;
    String endpoint = PerformanceSteps.Endpoint;
    String key = PerformanceSteps.Keys;
    int loop = PerformanceSteps.Loops;
    String ep = ConfigUtil.GET_ENDPOINT(endpoint);
    String baseuri = ConfigUtil.BASEURI("auth");
    ExcelUtil mg = new ExcelUtil();
    ArrayList<String> data = (ArrayList<String>) mg.getData(key);
    String body = data.get(1);
    String header = data.get(2);
    Map<String, String> headers = jsonToMap(header);

    String requestMethod = request.toLowerCase();
    HttpRequestActionBuilder httpRequest;
    HttpProtocolBuilder httpProtocol =
            http.baseUrl(baseuri)
                    .acceptHeader("text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                    .acceptLanguageHeader("en-US,en;q=0.5")
                    .acceptEncodingHeader("gzip, deflate")
                    .userAgentHeader("Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8; rv:16.0) Gecko/20100101 Firefox/16.0");


    ChainBuilder put =
            repeat(loop).on(
                    exec(
                            http("put")

                                    .put(ep)
                                    .queryParam("", data.get(3))
                                    .body(StringBody(body))
                                    .headers(headers)
                                    .formParam("", data.get(4))
                    ));

    ChainBuilder post =
            repeat(loop).on(
                    exec(
                            http("post")

                                    .post(ep)
                                    .queryParam("", data.get(3))
                                    .body(StringBody(body))
                                    .headers(headers)
                                    .formParam("", data.get(4))
                    ));

    ChainBuilder delete =
            repeat(loop).on(
                    exec(
                            http("delete")

                                    .delete(ep)
                                    .queryParam("", data.get(3))
                                    .body(StringBody(body))
                                    .headers(headers)
                                    .formParam("", data.get(4))
                    ));

    ChainBuilder get =
            repeat(loop).on(
                    exec(
                            http("get")

                                    .delete(ep)
                                    .queryParam("", data.get(3))
                                    .body(StringBody(body))
                                    .headers(headers)
                                    .formParam("", data.get(4))
                    ));
    ScenarioBuilder users1 = scenario("users1").exec(put);
    ScenarioBuilder users2 = scenario("users2").exec(post);
    ScenarioBuilder users3 = scenario("users3").exec(delete);
    ScenarioBuilder users4 = scenario("users3").exec(get);
    {
        if(requestMethod.equalsIgnoreCase("put")) {
            setUp(
                    users1.injectOpen(rampUsers(user).during(rampUP))
            ).protocols(httpProtocol);

        } else if (requestMethod.equalsIgnoreCase("post")) {
            setUp(
                    users2.injectOpen(rampUsers(user).during(rampUP))
            ).protocols(httpProtocol);
        } else if (requestMethod.equalsIgnoreCase("delete")) {
            setUp(
                    users3.injectOpen(rampUsers(user).during(rampUP))
            ).protocols(httpProtocol);
        }
        else if(requestMethod.equalsIgnoreCase("get")){
            setUp(
                    users4.injectOpen(rampUsers(user).during(rampUP))
            ).protocols(httpProtocol);
        }
    }

    public sample1() throws IOException {

    }
}
