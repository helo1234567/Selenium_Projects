//package com.spec;
//
//import io.qameta.allure.Configuration;
//import io.qameta.allure.core.LaunchResults;
//import io.qameta.allure.entity.TestResult;
//import io.qameta.allure.widget.Widget;
//import io.qameta.allure.model.Status;
//
//import java.io.IOException;
//import java.nio.file.Files;
//import java.nio.file.Path;
//import java.util.ArrayList;
//import java.util.Collection;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//import java.util.stream.Stream;
//
//public class MyPlugin implements Widget {
//
//
//    public Object getData(Configuration configuration, List<LaunchResults> launches) {
//        List<Map<String, Object>> widgetData = new ArrayList<>();
//
//        for (LaunchResults launch : launches) {
//            List<TestResult> results = (List<TestResult>) launch.getAllResults();
//
//            for (TestResult result : results) {
//                if (result.getStatus().equals(Status.FAILED)) {
//                    Map<String, Object> data = new HashMap<>();
//                    data.put("Sample time", result.getExtra()); // Assuming sampleTime is stored as an extra
//
//                    widgetData.add(data);
//                }
//            }
//        }
//
//        return widgetData;
//    }
//
//
//    public String getName() {
//        return "custom-sample-time-widget";
//    }
//
//
//    public Path export(Path outputDirectory, List<LaunchResults> launches) throws IOException {
//        List<Map<String, Object>> widgetData = (List<Map<String, Object>>) getData(null, launches);
//
//        Path widgetDataFile = outputDirectory.resolve("data/my-widget-data.json");
//
//        Files.createDirectories(widgetDataFile.getParent());
//        Files.write(widgetDataFile, widgetData.toString().getBytes());
//
//        return widgetDataFile;
//    }
//}
